(() => {
  // ../../.nifty/files/lazy/views/testassist/testassist.js
  var ATTRIBUTES = { propa: "" };
  var VTestAssist = class extends HTMLElement {
    m = { dummydata: [] };
    a = { ...ATTRIBUTES };
    s = { propa: false };
    shadow;
    static get observedAttributes() {
      return Object.keys(ATTRIBUTES);
    }
    constructor() {
      super();
      this.shadow = this.attachShadow({ mode: "open" });
    }
    async connectedCallback() {
    }
    async attributeChangedCallback(name, oldval, newval) {
      $N.CMech.AttributeChangedCallback(this, name, oldval, newval);
    }
    disconnectedCallback() {
      $N.CMech.ViewDisconnectedCallback(this);
    }
    kd(loadeddata, _loadstate, _pathparams, _searchparams) {
      const dummydata = loadeddata.get("dummydata") || [];
      this.m.dummydata = dummydata;
    }
    sc() {
      render(this.template(this.s, this.m), this.shadow);
    }
    template = (_s, _m) => {
      return html`<link rel='stylesheet' href='/assets/main.css'><style>

</style>
<header class="viewheader">
    <a class="left"><span>&nbsp;</span></a>
    <div class="middle"><h1>Test Assist</h1></div>
    <div class="right">
        &nbsp;
    </div>
</header>


<div class="wrapper">
	<div class="message-container">
		<strong>Test Assist</strong>
		<br>
		${_m.dummydata.map((m) => html`
			<div>${m.dummytext}</div>
		`)}
	</div>
</div>

`;
    };
  };
  customElements.define("v-testassist", VTestAssist);
})();
