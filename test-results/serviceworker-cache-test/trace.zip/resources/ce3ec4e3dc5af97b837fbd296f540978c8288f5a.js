(() => {
  // ../../.nifty/files/alwaysload/localdbsync.js
  var DBNAME = "";
  var DBVERSION = 0;
  var COLLECTION_TS = "localdbsync_collections_ts";
  var _syncobjectstores = [];
  var _activepaths = [];
  var _a_millis = 0;
  var Init = (localdb_objectstores_tosync, db_name, db_version) => {
    _a_millis = Math.floor(Date.now() / 1e3);
    DBNAME = db_name;
    DBVERSION = db_version;
    {
      const objectstores_tosync_names = localdb_objectstores_tosync.map((item) => item.name);
      const localstorage_syncobjectstores = JSON.parse(localStorage.getItem(COLLECTION_TS) || "[]");
      const synccollections_not_in_localstorage = objectstores_tosync_names.filter((name) => !localstorage_syncobjectstores.find((item) => item.name === name));
      synccollections_not_in_localstorage.forEach((name) => {
        localstorage_syncobjectstores.push({ name, ts: null });
      });
      _syncobjectstores = localstorage_syncobjectstores.map((dc, _i) => ({ name: dc.name, ts: dc.ts, lock: false, indexes: localdb_objectstores_tosync.find((l_ots) => l_ots.name === dc.name)?.indexes || null }));
      localStorage.setItem(COLLECTION_TS, JSON.stringify(localstorage_syncobjectstores));
      _activepaths = _syncobjectstores.filter((so) => so.ts !== null && so.ts > 0).map((so) => parse_into_pathspec(so.name));
    }
    return true;
  };
  var RunSyncFromEvent = async (eventname, event) => new Promise(async (res, _rej) => {
    if (eventname === "visible" || eventname === "15interval") {
      if (_activepaths.length === 0) {
        res();
        return;
      }
      await datasetter(_activepaths, {}, true);
      res();
      return;
    }
    if (eventname === "datasync_doc_add" || eventname === "datasync_doc_patch" || eventname === "datasync_doc_delete") {
      if (!event || !event.paths || !event.data) {
        console.error("RunSyncFromEvent: missing event, event.paths or event.data");
        return;
      }
      const ps = parse_into_pathspec(event.paths[0]);
      if (!ps.syncobjectstore) {
        res();
        return;
      }
      if (eventname === "datasync_doc_delete") {
        await $N.IDB.DeleteOne(ps.syncobjectstore.name, event.data.id);
      } else {
        await write_to_indexeddb_store([ps.syncobjectstore], [[event.data]]);
      }
      res();
      return;
    }
    if (eventname === "datasync_collection") {
      if (!event || !event.paths || !event.paths.length) {
        console.error("RunSyncFromEvent: missing event, event.paths or event.paths.length");
        return;
      }
      const ssepathspecs = event.paths.map((sp) => parse_into_pathspec(sp));
      const pathspecs = _activepaths.filter((aps) => ssepathspecs.find((sp) => sp.collection === aps.collection && sp.docid === aps.docid && sp.subcollection === aps.subcollection));
      if (pathspecs.length === 0) {
        res();
        return;
      }
      await datasetter(pathspecs, {}, true);
      res();
      return;
    }
  });
  var PreloadObjectStores = (names) => new Promise(async (res, rej) => {
    const pathspecs = names.map((name) => parse_into_pathspec(name));
    const newpathspecs = pathspecs.filter((pathspec) => !_activepaths.some((activePath) => activePath.collection === pathspec.collection && activePath.docid === pathspec.docid && activePath.subcollection === pathspec.subcollection));
    if (newpathspecs.length === 0) {
      res(1);
      return;
    }
    const r = await datasetter(newpathspecs, {}, false);
    if (r === null) {
      rej();
      return;
    }
    _activepaths = [..._activepaths, ...newpathspecs];
    res(1);
  });
  var Add = async (pathstr, data) => {
    const pathspec = parse_into_pathspec(pathstr);
    data.ts = Math.floor(Date.now() / 1e3);
    data.id = crypto.randomUUID();
    const cname = pathspec.syncobjectstore.name;
    const body = { path: cname, data, suppress_sse: true };
    const opts = { method: "POST", body: JSON.stringify(body) };
    const r = await $N.FetchLassie("/api/firestore_add", opts, null);
    if (!r.ok) {
      redirect_from_error("Add: FetchLassie Failed");
      return;
    }
    await $N.IDB.PutOne(cname, data);
  };
  var Patch = async (pathstr, newpartialdata) => {
    const pathspec = parse_into_pathspec(pathstr);
    const cname = pathspec.syncobjectstore.name;
    const ts = Math.floor(Date.now() / 1e3);
    const existingdata = await $N.IDB.GetOne(cname, pathspec.docid);
    const oldts = existingdata.ts;
    const newdata = merge_new_to_existing(existingdata, { ...newpartialdata, ts });
    const body = { path: pathspec.path, oldts, newdata: change_newdata_for_firestore_update(newdata), suppress_sse: true };
    const opts = { method: "POST", body: JSON.stringify(body) };
    const r = await $N.FetchLassie("/api/firestore_patch", opts, null);
    if (!r.ok || r.data.code !== 1) {
      redirect_from_error("Patch FetchLassie Failed. Server code: " + r.data.code);
      return;
    }
    await $N.IDB.PutOne(cname, newdata);
  };
  var Delete = async (pathstr) => {
    const pathspec = parse_into_pathspec(pathstr);
    const cname = pathspec.syncobjectstore.name;
    const existingdata = await $N.IDB.GetOne(cname, pathspec.docid);
    const oldts = existingdata.ts;
    const newts = Math.floor(Date.now() / 1e3);
    const body = { path: pathspec.path, oldts, ts: newts, suppress_sse: true };
    const opts = { method: "POST", body: JSON.stringify(body) };
    const r = await $N.FetchLassie("/api/firestore_delete", opts, null);
    if (!r.ok) {
      redirect_from_error("Delete FetchLassie Failed");
      return;
    }
    if (r.data?.code === 11) {
      await $N.IDB.PutOne(cname, r.data.data);
      redirect_from_error("Delete sorta failed. Was newer at server");
      return;
    }
    await $N.IDB.DeleteOne(cname, pathspec.docid);
  };
  var datasetter = (pathspecs, opts, force_refresh_syncobjectstores = false) => new Promise(async (res, _rej) => {
    opts = opts || {};
    const paths_tosync = pathspecs.filter((p) => p.syncobjectstore.ts === null || force_refresh_syncobjectstores);
    const syncobjectstores_tosync_withduplicates = paths_tosync.map((p) => p.syncobjectstore);
    const syncobjectstores_tosync = syncobjectstores_tosync_withduplicates.filter((item, index) => syncobjectstores_tosync_withduplicates.indexOf(item) === index);
    const syncobjectstores_tosync_unlocked = syncobjectstores_tosync.filter((dc) => !dc.lock);
    const syncobjectstores_tosync_locked = syncobjectstores_tosync.filter((dc) => dc.lock);
    {
      if (syncobjectstores_tosync_unlocked.length) {
        const rs = await load_into_syncobjectstores(syncobjectstores_tosync_unlocked);
        if (rs === null) {
          res(null);
          return;
        }
      }
      if (syncobjectstores_tosync_locked.length) {
        await new Promise((resolve_inner) => {
          const intrvl = setInterval(() => {
            if (syncobjectstores_tosync_locked.every((dc) => !dc.lock)) {
              clearInterval(intrvl);
              resolve_inner(1);
            }
          }, 10);
        });
      }
    }
    res(1);
  });
  function parse_into_pathspec(path) {
    const p = path.split("/");
    const collection = p[0];
    const docid = p[1] || null;
    const subcollection = docid && p[2] ? p[2] : null;
    const syncobjectstore = _syncobjectstores.find((dc) => dc.name === collection);
    return { path, p, collection, docid, subcollection, syncobjectstore };
  }
  var load_into_syncobjectstores = (syncobjectstores) => new Promise(async (res, _rej) => {
    syncobjectstores.forEach((dc) => dc.lock = true);
    const runidstring = Math.random().toString(15).substring(2, 12);
    let continue_calling = true;
    const paths = syncobjectstores.map((dc) => dc.name);
    const tses = syncobjectstores.map((dc) => dc.ts || null);
    const body = { runid: runidstring, paths, tses };
    while (continue_calling) {
      const r = await $N.FetchLassie("/api/firestore_get_batch", { method: "POST", body: JSON.stringify(body) }, {});
      if (!r.ok) {
        cleanup();
        await remove_all_records_after_ts(syncobjectstores);
        redirect_from_error("load_into_syncobjectstores FetchLassie Failed");
        return;
      }
      for (let i = 0; i < paths.length; i++) {
        if (r.data[i].docs.length === 0) continue;
        await write_to_indexeddb_store([syncobjectstores[i]], [r.data[i].docs]);
      }
      continue_calling = r.data.every((rr) => rr.isdone) ? false : true;
    }
    const newts = Math.floor(Date.now() / 1e3);
    syncobjectstores.forEach((dc) => dc.ts = newts);
    localStorage.setItem(COLLECTION_TS, JSON.stringify(_syncobjectstores.map((dc) => ({ name: dc.name, ts: dc.ts }))));
    cleanup();
    res(1);
    function cleanup() {
      continue_calling = false;
      syncobjectstores.forEach((dc) => dc.lock = false);
    }
  });
  var write_to_indexeddb_store = (syncobjectstores, datas) => new Promise(async (resolve, _reject) => {
    const deleteobjectstoreindexes = [];
    syncobjectstores.forEach((dc, i) => {
      if (dc.name === "__deleted_docs") deleteobjectstoreindexes.push(i);
    });
    const delete_syncobjectstores = deleteobjectstoreindexes.map((i) => syncobjectstores[i]);
    const delete_datas = deleteobjectstoreindexes.map((i) => datas[i]);
    const normal_syncobjectstores = syncobjectstores.filter((_, i) => !deleteobjectstoreindexes.includes(i));
    const normal_datas = datas.filter((_, i) => !deleteobjectstoreindexes.includes(i));
    const promises = [];
    promises.push($N.IDB.PutMany(normal_syncobjectstores.map((dc) => dc.name), normal_datas));
    promises.push($N.IDB.DeleteMany(delete_syncobjectstores.map((dc) => dc.name), delete_datas));
    await Promise.all(promises);
    resolve();
  });
  async function redirect_from_error(errmsg) {
    $N.Unrecoverable("Error", "Error in LocalDBSync", "Reset App", "lde", errmsg, null);
  }
  var remove_all_records_after_ts = async (syncobjectstores) => {
    const db = await $N.IDB.GetDB();
    for (const so of syncobjectstores) {
      await new Promise((resolve) => {
        const ts = so.ts || 0;
        let tx = db.transaction(so.name, "readwrite");
        const os = tx.objectStore(so.name);
        const idx = os.index("ts");
        const range = IDBKeyRange.lowerBound(ts, true);
        const req = idx.openCursor(range);
        req.onsuccess = () => {
          const cursor = req.result;
          if (!cursor) return;
          try {
            cursor.delete();
          } catch {
          }
          cursor.continue();
        };
        req.onerror = () => {
        };
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
        tx.onabort = () => resolve();
      });
    }
  };
  function merge_new_to_existing(existing, newpartial) {
    const merged = { ...existing };
    for (const key in newpartial) {
      if (!Object.prototype.hasOwnProperty.call(newpartial, key)) {
        continue;
      }
      const newvalue = newpartial[key];
      if (newvalue === void 0) {
        continue;
      }
      if (newvalue === null) {
        merged[key] = null;
        continue;
      }
      if (Array.isArray(newvalue)) {
        merged[key] = newvalue.slice();
        continue;
      }
      if (typeof newvalue === "object") {
        if (newvalue.__path) {
          merged[key] = newvalue;
          continue;
        }
        const isplainobject = Object.prototype.toString.call(newvalue) === "[object Object]";
        if (isplainobject) {
          const existingvalue = merged[key];
          const base = existingvalue && typeof existingvalue === "object" && !Array.isArray(existingvalue) ? { ...existingvalue } : {};
          merged[key] = merge_new_to_existing(base, newvalue);
          continue;
        }
        merged[key] = newvalue;
        continue;
      }
      merged[key] = newvalue;
    }
    return merged;
  }
  function change_newdata_for_firestore_update(newdata) {
    const firestore_ready_data = {};
    for (const key in newdata) {
      if (typeof newdata[key] === "object" && newdata[key] !== null) {
        if (newdata[key].__path) {
          firestore_ready_data[key] = newdata[key];
        } else if (Array.isArray(newdata[key])) {
          firestore_ready_data[key] = newdata[key];
        } else {
          for (const subkey in newdata[key]) {
            firestore_ready_data[`${key}.${subkey}`] = newdata[key][subkey];
          }
        }
      } else {
        firestore_ready_data[key] = newdata[key];
      }
    }
    return firestore_ready_data;
  }

  // ../../.nifty/files/alwaysload/datahodl.js
  var _viewsdata = /* @__PURE__ */ new Map();
  var _all_lazyload_data_funcs = [];
  var Init2 = (lazyload_data_funcs) => {
    _all_lazyload_data_funcs = lazyload_data_funcs;
    $N.EngagementListen.Add_Listener(document.body, "datahodl_visible", ["visible", "15interval"], 100, handle_engagement_event);
    $N.SSEvents.Add_Listener(document.body, "datahodl", ["datasync_doc_delete", "datasync_doc_add", "datasync_doc_patch", "datasync_collection"], 100, handle_sse_event);
    document.querySelector("#views").addEventListener("hydrated", handle_viewhydrated_event);
    document.querySelector("#views").addEventListener("initial_hydration", handle_initialhydration_event);
    document.querySelector("#views").addEventListener("visibled", handle_viewvisibled_event);
    document.addEventListener("backonline", handle_backonline_event);
  };
  var LoadViewData = (viewname, pathparams, searchparams, localdb_preload) => new Promise(async (res, rej) => {
    let loadr;
    try {
      if (localdb_preload && localdb_preload.length) await PreloadObjectStores(localdb_preload);
      loadr = await _all_lazyload_data_funcs[viewname](pathparams, searchparams, {});
    } catch {
      rej();
      return;
    }
    const refreshon = loadr.refreshon || [];
    _viewsdata.set(viewname, { pathparams, searchparams, loadeddata: loadr.d, refreshon });
    res();
  });
  var GetViewData = (viewname) => {
    return _viewsdata.get(viewname);
  };
  var RemoveViewData = (viewname) => {
    _viewsdata.delete(viewname);
  };
  var AddLocalDB = (pathstr, data) => {
    Add(pathstr, data);
    run_update_from_local_db_addpatchdelete([pathstr]);
  };
  var PatchLocalDB = (pathstr, newdata) => {
    Patch(pathstr, newdata);
    run_update_from_local_db_addpatchdelete([pathstr]);
  };
  var DeleteLocalDB = (pathstr) => {
    Delete(pathstr);
    run_update_from_local_db_addpatchdelete([pathstr]);
  };
  var run_update_from_local_db_addpatchdelete = async (paths) => {
    update_affected_views(paths);
  };
  var update_nonspecific = async (eventname) => {
    if (!window.navigator.onLine) {
      return;
    }
    const paths = /* @__PURE__ */ new Set();
    let r = null;
    const promises = [RunSyncFromEvent(eventname)];
    try {
      r = await Promise.all(promises);
    } catch {
      redirect_from_error2("datahodl_visible: unable to refresh all caches");
      return;
    }
    for (const [_vn, v] of [..._viewsdata]) {
      for (const p of v.refreshon) paths.add(p);
    }
    if (paths.size) update_affected_views([...paths]);
  };
  var handle_engagement_event = async (eventname) => {
    await update_nonspecific(eventname);
  };
  var handle_sse_event = async (event, eventname) => {
    let r = null;
    event.paths = eventname === "datasync_collection" ? event.paths : [event.paths[0]];
    const promises = [];
    if (eventname === "datasync_doc_add") eventname = "datasync_collection";
    promises.push(RunSyncFromEvent(eventname, event));
    try {
      r = await Promise.all(promises);
    } catch {
      redirect_from_error2("datahodl_sse_event_sync_error: unable to refresh all caches");
      return;
    }
    update_affected_views(event.paths);
  };
  var handle_initialhydration_event = async (_ev) => {
  };
  var handle_viewhydrated_event = async (_ev) => {
  };
  var handle_viewvisibled_event = async (_ev) => {
  };
  var handle_backonline_event = async (_ev) => {
    await update_nonspecific("backonline");
  };
  var update_affected_views = async (paths) => {
    const pathspecs = paths.map((p) => {
      const parts = p.split("/");
      return { path: p, collection: parts[0], docid: parts.length > 1 ? parts[1] : null };
    });
    const affected_views = new Map([..._viewsdata].filter(([_k, v]) => {
      for (const pathspec of pathspecs) {
        if (v.refreshon.includes(pathspec.path)) return true;
        else if (!pathspec.docid && v.refreshon.some((r) => r.startsWith(pathspec.collection))) return true;
        else if (pathspec.docid && v.refreshon.some((r) => r === pathspec.collection || r === `${pathspec.collection}/${pathspec.docid}`)) return true;
      }
      return false;
    }));
    const promises = [];
    for (const [viewname, v] of [...affected_views]) {
      promises.push(LoadViewData(viewname, v.pathparams, v.searchparams));
    }
    try {
      await Promise.all(promises);
    } catch {
      redirect_from_error2("RunUpdateFromLocalDBUpdate: unable to refresh all affected views");
      return false;
    }
    for (const [viewname, v] of [...affected_views]) {
      UpdateFromChangedData(viewname, v.pathparams, v.searchparams, v.loadeddata, "server_state_change");
    }
  };
  async function redirect_from_error2(errmsg) {
    $N.Unrecoverable("Error", "Error in DataHodl", "Reset App", "dhl", errmsg, null);
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.DataHodl = { AddLocalDB, PatchLocalDB, DeleteLocalDB };

  // ../../.nifty/files/alwaysload/cmech.js
  var _views = /* @__PURE__ */ new Map();
  var _viewsel = document.body;
  var _has_initial_page_hydrated = false;
  var Init3 = () => {
    _viewsel = document.getElementById("views");
    document.body.querySelector("#views").addEventListener("hydrated", (_ev) => {
    });
    document.body.querySelector("#views").addEventListener("visibled", (_ev) => {
    });
    $N.EngagementListen.Add_Listener(_viewsel, "cmech_view_resize_listener", ["resize"], null, update_from_resize);
  };
  var AddView = (viewname, pathparams, searchparams, localdb_preload) => new Promise(async (res, rej) => {
    _views.set(viewname, { pathparams, searchparams });
    try {
      await LoadViewData(viewname, pathparams, searchparams, localdb_preload);
    } catch {
      remove_view_aux(viewname);
      rej();
      return;
    }
    const parentEl = document.querySelector("#views");
    parentEl.insertAdjacentHTML("beforeend", `<v-${viewname} class='view'></v-${viewname}>`);
    await hydrate_view(viewname).catch(() => null);
    res(1);
  });
  var RegisterViewPart = (component) => {
    const tagname = component.tagName.toLowerCase();
    const tagname_split = tagname.split("-");
    if (tagname_split[0] !== "vp") throw new Error("Not a view part component");
    const rootnode = component.getRootNode();
    const host = rootnode.host;
    const ancestor_view_tagname = host.tagName.toLowerCase();
    const ancestor_view_tagname_split = ancestor_view_tagname.split("-");
    const ancestor_viewname = ancestor_view_tagname_split[1];
    for (const prop in component.a) component.a[prop] = component.getAttribute(prop);
    host.subelshldr.push(component);
    component.hostview = host;
    const d = GetViewData(ancestor_viewname);
    component.kd(d.loadeddata, "initial", d.pathparams, d.searchparams);
    component.sc();
  };
  var AttributeChangedCallback = (component, name, oldval, newval, _opts) => new Promise((res) => {
    if (oldval === null) return;
    const a = component.a;
    a[name] = newval;
    if (!a.updatescheduled) {
      a.updatescheduled = true;
      Promise.resolve().then(() => {
        a.updatescheduled = false;
        res();
      });
    }
  });
  var ViewDisconnectedCallback = (component) => {
    remove_view_aux(component.tagName.toLowerCase().split("-")[1]);
  };
  var ViewPartDisconnectedCallback = (component) => {
    component.hostview.subelshldr.splice(component.hostview.subelshldr.indexOf(component), 1);
  };
  var UpdateFromChangedParams = (viewname, pathparams, searchparams) => new Promise(async (res, rej) => {
    const viewel = document.querySelector(`#views > v-${viewname}`);
    _views.set(viewname, { pathparams, searchparams });
    try {
      await LoadViewData(viewname, pathparams, searchparams);
    } catch {
      remove_view_aux(viewname);
      rej();
      return;
    }
    const loadeddata = GetViewData(viewname).loadeddata;
    for (const subel of viewel.subelshldr) {
      subel.kd(loadeddata, "paramschanged", pathparams, searchparams);
      subel.sc();
    }
    viewel.kd(loadeddata, "paramschanged", pathparams, searchparams);
    viewel.sc();
    res();
  });
  var UpdateFromChangedData = (viewname, pathparams, searchparams, loadeddata, eventname = "paramschanged") => {
    const viewel = document.querySelector(`#views > v-${viewname}`);
    for (const subel of viewel.subelshldr) {
      subel.kd(loadeddata, eventname, pathparams, searchparams);
      subel.sc();
    }
    viewel.kd(loadeddata, eventname, pathparams, searchparams);
    viewel.sc();
  };
  var hydrate_view = (viewname) => new Promise(async (res, _rej) => {
    const component = document.querySelector(`#views > v-${viewname}`);
    for (const prop in component.a) component.a[prop] = component.getAttribute(prop);
    component.subelshldr = [];
    const d = GetViewData(viewname);
    component.kd(d.loadeddata, "initial", d.pathparams, d.searchparams);
    component.sc();
    const eventname = _has_initial_page_hydrated ? "hydrated" : "initial_hydration";
    _has_initial_page_hydrated = true;
    res();
    component.parentElement.dispatchEvent(new CustomEvent(eventname, { detail: { viewname } }));
    return;
  });
  var update_from_resize = () => {
    const allviews = Array.from(_viewsel.children);
    for (const view of allviews) {
      for (const subel of view.subelshldr) {
        subel.sc();
      }
      view.sc();
    }
  };
  var remove_view_aux = (viewname) => {
    _views.delete(viewname);
    RemoveViewData(viewname);
  };
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.CMech = { RegisterViewPart, AttributeChangedCallback, ViewDisconnectedCallback, ViewPartDisconnectedCallback };

  // ../../.nifty/files/alwaysload/switchstation_uri.js
  var RegExParams = (original_matchstr) => {
    const pathparamnames = [];
    const pattern = original_matchstr.replace(/:([a-zA-Z_0-9]+)/g, (_match, pathparamname) => {
      pathparamnames.push(pathparamname);
      return "([a-zA-Z0-9_]+)";
    });
    const regex = new RegExp(pattern);
    const paramnames = pathparamnames;
    return { regex, paramnames, pattern };
  };
  var GetPathParams = (pathparams_propnames, pathparams_vals) => {
    const pathparams = pathparams_propnames.map((_, i) => {
      return { [pathparams_propnames[i]]: pathparams_vals[i] };
    });
    return Object.assign({}, ...pathparams);
  };

  // ../../.nifty/files/alwaysload/switchstation_parsepath.js
  function ParsePath(path, allroutes) {
    const subsplit = path.split("/s/");
    const qsplit = path.split("?");
    const searchstr = qsplit.length > 1 ? qsplit[1] : "";
    const viewpathstr = subsplit.length > 1 ? subsplit[0] : qsplit[0];
    const substr = subsplit.length > 1 ? subsplit[1].split("?")[0] : "";
    let pathparams = {};
    let route;
    let searchparams = {};
    {
      for (let i = 0; i < allroutes.length; i++) {
        let pathmatch = viewpathstr.match(allroutes[i].path_regex);
        if (!pathmatch) continue;
        route = allroutes[i];
        pathparams = GetPathParams(route.pathparams_propnames, pathmatch.slice(1));
        break;
      }
      if (!route) {
        return null;
      }
      for (const [key, val] of new URLSearchParams(searchstr).entries()) {
        searchparams[key] = val;
      }
    }
    if (!substr) {
      return { route, pathparams, searchparams };
    }
    for (const s of route.lazyload_view.subs) {
      const { regex, paramnames } = RegExParams(s.urlmatch);
      const match = substr.match(regex);
      if (!match) {
        continue;
      }
      const subpathparams = GetPathParams(paramnames, match.slice(1));
      const loadfunc = s.loadfunc || null;
      pathparams = { ...pathparams, ...subpathparams };
      return { route, pathparams, searchparams, sub: { loadfunc } };
    }
  }

  // ../../.nifty/files/alwaysload/switchstation_animate.js
  var Slide = async (old_view, new_view) => {
    new_view.style.opacity = "0";
    new_view.style.transform = "translate3d(10vw, 0, 0)";
    new_view.style.willChange = "transform, opacity";
    old_view.style.willChange = "transform, opacity";
    const old_view_kf = [{ transform: "translate3d(0, 0, 0)", opacity: 1 }, { transform: "translate3d(-10vw, 0, 0)", opacity: 0.8 }];
    const new_view_kf = [{ transform: "translate3d(10vw, 0, 0)", opacity: 0 }, { transform: "translate3d(0, 0, 0)", opacity: 1 }];
    const old_view_opts = { duration: 300, easing: "cubic-bezier(0.25, 0.1, 0.25, 1)", fill: "forwards" };
    const new_view_opts = { duration: 300, easing: "cubic-bezier(0.25, 0.1, 0.25, 1)", fill: "forwards", delay: 50 };
    const old_animation = old_view.animate(old_view_kf, old_view_opts);
    const new_animation = new_view.animate(new_view_kf, new_view_opts);
    Promise.all([old_animation.finished, new_animation.finished]).then(() => {
      old_view.style.visibility = "hidden";
      old_view.dataset.active = "false";
      old_view.style.willChange = "auto";
      new_view.style.willChange = "auto";
      new_view.dataset.active = "true";
      document.querySelector("#views").dispatchEvent(new Event("animationcomplete"));
    });
  };
  var SlideBack = async (current_view, previous_view) => {
    previous_view.style.visibility = "visible";
    previous_view.style.willChange = "transform, opacity";
    current_view.style.willChange = "transform, opacity";
    const current_view_kf = [{ transform: "translate3d(0, 0, 0)", opacity: 1 }, { transform: "translate3d(10vw, 0, 0)", opacity: 0 }];
    const previous_view_kf = [{ transform: "translate3d(-10vw, 0, 0)", opacity: 0.8 }, { transform: "translate3d(0, 0, 0)", opacity: 1 }];
    const current_view_opts = { duration: 300, easing: "cubic-bezier(0.25, 0.1, 0.25, 1)", fill: "forwards" };
    const previous_view_opts = { duration: 300, easing: "cubic-bezier(0.25, 0.1, 0.25, 1)", fill: "forwards", delay: 50 };
    const current_animation = current_view.animate(current_view_kf, current_view_opts);
    const previous_animation = previous_view.animate(previous_view_kf, previous_view_opts);
    await Promise.all([current_animation.finished, previous_animation.finished]);
    current_view.style.willChange = "auto";
    previous_view.style.willChange = "auto";
    current_view.dataset.active = "false";
    previous_view.dataset.active = "true";
    document.querySelector("#views").dispatchEvent(new Event("animationcomplete"));
  };

  // ../../.nifty/files/alwaysload/lazyload_files.js
  var _lazyloads = [];
  var _loaded = /* @__PURE__ */ new Map();
  var timeoutWaitingAnimateId = null;
  function Init4(lazyloads_) {
    _lazyloads = lazyloads_;
    const script_tags = document.head.querySelectorAll("script[is_lazyload_asset]");
    const keymap = /* @__PURE__ */ new Map();
    lazyloads_.forEach((lazyload) => {
      const key = get_filepath(lazyload.type, lazyload.name, lazyload.is_instance);
      keymap.set(key, lazyload);
    });
    script_tags.forEach((script) => {
      const src = script.getAttribute("src");
      if (!src) return;
      const lazyload = keymap.get(src);
      _loaded.set(src, lazyload);
    });
  }
  function LoadView(lazyloadview) {
    return new Promise(async (res, rej) => {
      setBackgroundOverlay(true);
      timeoutWaitingAnimateId = setTimeout(() => {
        setWaitingAnimate(true);
      }, 1e3);
      const loadque = [];
      addtoque(lazyloadview, loadque);
      const r = await retrieve_loadque(loadque);
      clearTimeout(timeoutWaitingAnimateId);
      setBackgroundOverlay(false);
      setWaitingAnimate(false);
      if (r === null) {
        rej();
        return;
      }
      res(1);
    });
  }
  function addtoque(load, loadque) {
    const load_key = get_filepath(load.type, load.name, load.is_instance);
    if (load.dependencies && load.dependencies.length !== 0) {
      for (const dep of load.dependencies) {
        const dep_load = _lazyloads.find((l) => l.type === dep.type && l.name === dep.name);
        addtoque(dep_load, loadque);
      }
    }
    if (!_loaded.has(load_key)) loadque.push(load);
  }
  function retrieve_loadque(loadque) {
    return new Promise(async (res, _rej) => {
      const promises = [];
      const filepaths = loadque.map((l) => get_filepath(l.type, l.name, l.is_instance));
      for (const f of filepaths) {
        promises.push(import_file(f));
      }
      try {
        await Promise.all(promises);
      } catch {
        res(null);
        return;
      }
      for (const load of loadque) {
        const load_key = get_filepath(load.type, load.name, load.is_instance);
        _loaded.set(load_key, load);
      }
      res(1);
    });
  }
  var import_file = (path) => new Promise((res, rej) => {
    import(path).then((module) => {
      res(module);
    }).catch((err) => {
      rej(err);
    });
  });
  function get_filepath(type, name, is_instance) {
    let path = is_instance ? `/assets/instance/` : "/assets/";
    switch (type) {
      case "view":
        path += `lazy/views/${name}/${name}.js`;
        break;
      case "component":
        path += `lazy/components/${name}/${name}.js`;
        break;
      case "thirdparty":
        path += `thirdparty/${name}.js`;
        break;
      case "workers":
        path += `lazy/workers/${name}.js`;
        break;
      case "lib":
        path += `lazy/libs/${name}.js`;
        break;
      case "directive":
        path += `lazy/directives/${name}.js`;
        break;
    }
    return path;
  }
  function setBackgroundOverlay(ison) {
    const xel = document.querySelector("#lazyload_overlay");
    if (ison) {
      xel.classList.add("active");
    } else {
      xel.classList.remove("active");
    }
  }
  function setWaitingAnimate(ison) {
    const xel = document.querySelector("#lazyload_overlay .waiting_animate");
    if (ison) {
      xel.classList.add("active");
    } else {
      xel.classList.remove("active");
    }
  }

  // ../../.nifty/files/alwaysload/switchstation_handlebackswipe.js
  var EDGE_ZONE = 20;
  var SWIPE_VELOCITY_THRESHOLD = 0.3;
  var MIN_SWIPE_DISTANCE = 50;
  var BackSwipeHandler = class {
    swipe_state;
    prepare_view_callback = null;
    is_native_swipe_callback = null;
    constructor() {
      const is_ios = /iPhone|iPad/.test(navigator.userAgent);
      const is_safari = /Safari/.test(navigator.userAgent);
      const is_not_chrome = !/Chrome|CriOS/.test(navigator.userAgent);
      this.swipe_state = { is_ios_safari: is_ios && is_safari && is_not_chrome, is_native_swipe: false, swipe_start_x: 0, swipe_start_time: 0, touch_identifier: null };
      if (this.swipe_state.is_ios_safari) {
        this.init_listeners();
      }
    }
    init_listeners() {
      window.addEventListener("touchstart", (e) => {
        const touch = e.touches[0];
        if (touch.clientX < EDGE_ZONE) {
          this.swipe_state.swipe_start_x = touch.clientX;
          this.swipe_state.swipe_start_time = Date.now();
          this.swipe_state.touch_identifier = touch.identifier;
          this.swipe_state.is_native_swipe = true;
        }
      }, { passive: true });
      window.addEventListener("touchmove", (e) => {
        if (!this.swipe_state.is_native_swipe || this.swipe_state.touch_identifier === null) return;
        const touch = Array.from(e.touches).find((t) => t.identifier === this.swipe_state.touch_identifier);
        if (!touch) return;
        const delta_x = touch.clientX - this.swipe_state.swipe_start_x;
        const delta_time = Date.now() - this.swipe_state.swipe_start_time;
        if (delta_x > MIN_SWIPE_DISTANCE && delta_time > 0) {
          const velocity = delta_x / delta_time;
          if (velocity > SWIPE_VELOCITY_THRESHOLD) {
            this.prepare_views_for_native_swipe();
          }
        } else if (delta_x < -10) {
          this.swipe_state.is_native_swipe = false;
        }
      }, { passive: true });
      window.addEventListener("touchend", (e) => {
        if (this.swipe_state.touch_identifier === null) return;
        const ended_touch = Array.from(e.changedTouches).find((t) => t.identifier === this.swipe_state.touch_identifier);
        if (ended_touch) {
          const delta_x = ended_touch.clientX - this.swipe_state.swipe_start_x;
          const delta_time = Date.now() - this.swipe_state.swipe_start_time;
          if (delta_x < MIN_SWIPE_DISTANCE || delta_time > 0 && delta_x / delta_time < SWIPE_VELOCITY_THRESHOLD) {
            this.swipe_state.is_native_swipe = false;
          }
          this.swipe_state.touch_identifier = null;
        }
      }, { passive: true });
      window.addEventListener("touchcancel", () => {
        this.swipe_state.is_native_swipe = false;
        this.swipe_state.touch_identifier = null;
      }, { passive: true });
    }
    prepare_views_for_native_swipe() {
      if (this.prepare_view_callback) {
        this.prepare_view_callback();
      }
    }
    on_prepare_view(callback) {
      this.prepare_view_callback = callback;
    }
    was_native_swipe() {
      const was_swipe = this.swipe_state.is_native_swipe;
      this.swipe_state.is_native_swipe = false;
      return was_swipe;
    }
    is_ios_safari() {
      return this.swipe_state.is_ios_safari;
    }
  };
  var back_swipe_handler = new BackSwipeHandler();

  // ../../.nifty/files/alwaysload/switchstation.js
  var _routes = [];
  var _navstack = [];
  var Init5 = () => new Promise(async (res, _rej) => {
    _routes.sort((a, b) => {
      const a_source = a.path_regex.source;
      const b_source = b.path_regex.source;
      const a_specificity = a_source.replace(/[.*+?^${}()|[\]\\]/g, "").length;
      const b_specificity = b_source.replace(/[.*+?^${}()|[\]\\]/g, "").length;
      return b_specificity - a_specificity;
    });
    let path;
    if (window.location.pathname === "/" || window.location.pathname === "" || window.location.pathname === "/index.html") {
      path = "home";
    } else {
      path = window.location.pathname.slice(3) + window.location.search;
    }
    GoTo(path);
    back_swipe_handler.on_prepare_view(() => {
      const viewsel = document.getElementById("views");
      const allviews = Array.from(viewsel.children);
      if (allviews.length >= 2) {
        const previousview = allviews[allviews.length - 2];
        previousview.style.visibility = "visible";
        previousview.style.opacity = "1";
        previousview.style.transform = "translate3d(0, 0, 0)";
      }
    });
    window.addEventListener("popstate", on_popstate);
    res();
  });
  async function GoTo(path) {
    const pathspec = ParsePath(path, _routes);
    if (!pathspec) {
      route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to parse path", true);
      return;
    }
    let currentpathspec;
    if (!_navstack.length) {
      currentpathspec = null;
      history.replaceState({}, "", "/v/" + path);
    } else {
      currentpathspec = _navstack[_navstack.length - 1];
      history.pushState({}, "", "/v/" + path);
    }
    const pathspecclone = structuredClone(pathspec);
    _navstack.push(pathspecclone);
    if (!currentpathspec || currentpathspec.route.lazyload_view.name !== pathspec.route.lazyload_view.name) {
      try {
        await activate_view(pathspec);
      } catch {
        route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to activate view", true);
        return;
      }
    } else {
      try {
        await paramschanged(pathspec);
      } catch {
        route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to activate subview", true);
        return;
      }
    }
    $N.Logger.log(20, "srg", `${path}`);
    return;
  }
  async function GoBack(opts) {
    const previous_pathspec = _navstack[_navstack.length - 2];
    if (!previous_pathspec) {
      if (!opts) opts = { default: "home" };
      const defaultpath = opts.default || "home";
      const pathspec = ParsePath(defaultpath, _routes);
      if (!pathspec) {
        route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to navigate back. ParsePath method failed", true);
        return;
      }
      const viewsel = document.getElementById("views");
      viewsel.innerHTML = "";
      try {
        await activate_view(pathspec);
      } catch {
        route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to activate view on navigate back", true);
        return;
      }
      history.replaceState({}, "", "/v/" + defaultpath);
      _navstack = [];
      _navstack.push(pathspec);
      return;
    }
    history.back();
  }
  function Get_Lazyload_View_Url_Patterns(lazyloads) {
    return lazyloads.filter((l) => l.type === "view").map((r) => register_route(r)).map((l) => [l.viewname, l.pattern]);
  }
  var register_route = (lazyload_view) => {
    const { regex, paramnames: pathparams_propnames, pattern } = RegExParams(lazyload_view.urlmatch);
    _routes.push({ lazyload_view, path_regex: regex, pathparams_propnames });
    return { viewname: lazyload_view.name, pattern };
  };
  var activate_view = (pathspec) => new Promise(async (res, rej) => {
    const viewsel = document.getElementById("views");
    const old_view = viewsel.querySelector('[data-active="true"]');
    try {
      await LoadView(pathspec.route.lazyload_view);
      await AddView(pathspec.route.lazyload_view.name, pathspec.pathparams, pathspec.searchparams, pathspec.route.lazyload_view.localdb_preload || []);
    } catch {
      rej();
      return;
    }
    const new_view = viewsel.lastElementChild;
    if (old_view) {
      Slide(old_view, new_view);
      const animation_listener = () => {
        viewsel.dataset.active = "true";
        viewsel.removeEventListener("animationcomplete", animation_listener);
        viewsel.dispatchEvent(new CustomEvent("visibled", { detail: { viewname: pathspec.route.lazyload_view.name } }));
        res();
      };
      viewsel.addEventListener("animationcomplete", animation_listener);
    } else {
      new_view.dataset.active = "true";
      new_view.style.opacity = "1";
      new_view.style.visibility = "visible";
      new_view.style.transform = "translate3d(0, 0, 0)";
      document.querySelector("#views").dispatchEvent(new CustomEvent("visibled", { detail: { viewname: pathspec.route.lazyload_view.name } }));
      res();
    }
  });
  var paramschanged = (pathspec) => new Promise(async (res, rej) => {
    try {
      await UpdateFromChangedParams(pathspec.route.lazyload_view.name, pathspec.pathparams, pathspec.searchparams);
    } catch {
      rej();
      return;
    }
    res();
  });
  var on_popstate = async (_event) => {
    const lastpathspec = structuredClone(_navstack[_navstack.length - 2]);
    const currentpathspec = structuredClone(_navstack[_navstack.length - 1]);
    _navstack.pop();
    if (currentpathspec.route.lazyload_view.name !== lastpathspec.route.lazyload_view.name) {
      const viewsel = document.getElementById("views");
      const allviews = Array.from(viewsel.children);
      const currentview = allviews[allviews.length - 1];
      const previousview = allviews[allviews.length - 2];
      const was_native_swipe = back_swipe_handler.was_native_swipe();
      if (was_native_swipe) {
        viewsel.removeChild(currentview);
        previousview.dataset.active = "true";
      } else {
        await SlideBack(currentview, previousview);
        viewsel.removeChild(currentview);
      }
      return;
    }
    try {
      await paramschanged(lastpathspec);
    } catch {
      route_failed(_routes.find((r) => r.lazyload_view.name === "appmsgs"), "unable to navigate back to sub", true);
      return;
    }
    return;
  };
  var route_failed = (route, msg, redirect = false) => {
    if (redirect) {
      const routename = route.lazyload_view.name;
      $N.Unrecoverable("Unable to Load Page", msg, "Back to Home", "srf", `route: ${routename}`, "/v/home");
    } else {
      $N.ToastShow(msg, 4);
    }
  };
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.SwitchStation = { GoTo, GoBack };

  // ../../.nifty/files/thirdparty/lit-html.js
  (() => {
    var t = globalThis;
    var e = t.ShadowRoot && (void 0 === t.ShadyCSS || t.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;
    var s = Symbol();
    var o = /* @__PURE__ */ new WeakMap();
    var n = class {
      constructor(t4, e6, o6) {
        if (this._$cssResult$ = true, o6 !== s) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
        this.cssText = t4, this.t = e6;
      }
      get styleSheet() {
        let t4 = this.o;
        const s4 = this.t;
        if (e && void 0 === t4) {
          const e6 = void 0 !== s4 && 1 === s4.length;
          e6 && (t4 = o.get(s4)), void 0 === t4 && ((this.o = t4 = new CSSStyleSheet()).replaceSync(this.cssText), e6 && o.set(s4, t4));
        }
        return t4;
      }
      toString() {
        return this.cssText;
      }
    };
    var r = (t4) => new n("string" == typeof t4 ? t4 : t4 + "", void 0, s);
    var i = (t4, ...e6) => {
      const o6 = 1 === t4.length ? t4[0] : e6.reduce(((e7, s4, o7) => e7 + ((t5) => {
        if (true === t5._$cssResult$) return t5.cssText;
        if ("number" == typeof t5) return t5;
        throw Error("Value passed to 'css' function must be a 'css' function result: " + t5 + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
      })(s4) + t4[o7 + 1]), t4[0]);
      return new n(o6, t4, s);
    };
    var S = (s4, o6) => {
      if (e) s4.adoptedStyleSheets = o6.map(((t4) => t4 instanceof CSSStyleSheet ? t4 : t4.styleSheet));
      else for (const e6 of o6) {
        const o7 = document.createElement("style"), n4 = t.litNonce;
        void 0 !== n4 && o7.setAttribute("nonce", n4), o7.textContent = e6.cssText, s4.appendChild(o7);
      }
    };
    var c = e ? (t4) => t4 : (t4) => t4 instanceof CSSStyleSheet ? ((t5) => {
      let e6 = "";
      for (const s4 of t5.cssRules) e6 += s4.cssText;
      return r(e6);
    })(t4) : t4;
    var { is: i2, defineProperty: e2, getOwnPropertyDescriptor: h, getOwnPropertyNames: r2, getOwnPropertySymbols: o2, getPrototypeOf: n2 } = Object;
    var a = globalThis;
    var c2 = a.trustedTypes;
    var l = c2 ? c2.emptyScript : "";
    var p = a.reactiveElementPolyfillSupport;
    var d = (t4, s4) => t4;
    var u = { toAttribute(t4, s4) {
      switch (s4) {
        case Boolean:
          t4 = t4 ? l : null;
          break;
        case Object:
        case Array:
          t4 = null == t4 ? t4 : JSON.stringify(t4);
      }
      return t4;
    }, fromAttribute(t4, s4) {
      let i6 = t4;
      switch (s4) {
        case Boolean:
          i6 = null !== t4;
          break;
        case Number:
          i6 = null === t4 ? null : Number(t4);
          break;
        case Object:
        case Array:
          try {
            i6 = JSON.parse(t4);
          } catch (t5) {
            i6 = null;
          }
      }
      return i6;
    } };
    var f = (t4, s4) => !i2(t4, s4);
    var b = { attribute: true, type: String, converter: u, reflect: false, useDefault: false, hasChanged: f };
    Symbol.metadata ??= Symbol("metadata"), a.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
    var y = class extends HTMLElement {
      static addInitializer(t4) {
        this._$Ei(), (this.l ??= []).push(t4);
      }
      static get observedAttributes() {
        return this.finalize(), this._$Eh && [...this._$Eh.keys()];
      }
      static createProperty(t4, s4 = b) {
        if (s4.state && (s4.attribute = false), this._$Ei(), this.prototype.hasOwnProperty(t4) && ((s4 = Object.create(s4)).wrapped = true), this.elementProperties.set(t4, s4), !s4.noAccessor) {
          const i6 = Symbol(), h3 = this.getPropertyDescriptor(t4, i6, s4);
          void 0 !== h3 && e2(this.prototype, t4, h3);
        }
      }
      static getPropertyDescriptor(t4, s4, i6) {
        const { get: e6, set: r4 } = h(this.prototype, t4) ?? { get() {
          return this[s4];
        }, set(t5) {
          this[s4] = t5;
        } };
        return { get: e6, set(s5) {
          const h3 = e6?.call(this);
          r4?.call(this, s5), this.requestUpdate(t4, h3, i6);
        }, configurable: true, enumerable: true };
      }
      static getPropertyOptions(t4) {
        return this.elementProperties.get(t4) ?? b;
      }
      static _$Ei() {
        if (this.hasOwnProperty(d("elementProperties"))) return;
        const t4 = n2(this);
        t4.finalize(), void 0 !== t4.l && (this.l = [...t4.l]), this.elementProperties = new Map(t4.elementProperties);
      }
      static finalize() {
        if (this.hasOwnProperty(d("finalized"))) return;
        if (this.finalized = true, this._$Ei(), this.hasOwnProperty(d("properties"))) {
          const t5 = this.properties, s4 = [...r2(t5), ...o2(t5)];
          for (const i6 of s4) this.createProperty(i6, t5[i6]);
        }
        const t4 = this[Symbol.metadata];
        if (null !== t4) {
          const s4 = litPropertyMetadata.get(t4);
          if (void 0 !== s4) for (const [t5, i6] of s4) this.elementProperties.set(t5, i6);
        }
        this._$Eh = /* @__PURE__ */ new Map();
        for (const [t5, s4] of this.elementProperties) {
          const i6 = this._$Eu(t5, s4);
          void 0 !== i6 && this._$Eh.set(i6, t5);
        }
        this.elementStyles = this.finalizeStyles(this.styles);
      }
      static finalizeStyles(s4) {
        const i6 = [];
        if (Array.isArray(s4)) {
          const e6 = new Set(s4.flat(1 / 0).reverse());
          for (const s5 of e6) i6.unshift(c(s5));
        } else void 0 !== s4 && i6.push(c(s4));
        return i6;
      }
      static _$Eu(t4, s4) {
        const i6 = s4.attribute;
        return false === i6 ? void 0 : "string" == typeof i6 ? i6 : "string" == typeof t4 ? t4.toLowerCase() : void 0;
      }
      constructor() {
        super(), this._$Ep = void 0, this.isUpdatePending = false, this.hasUpdated = false, this._$Em = null, this._$Ev();
      }
      _$Ev() {
        this._$ES = new Promise(((t4) => this.enableUpdating = t4)), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach(((t4) => t4(this)));
      }
      addController(t4) {
        (this._$EO ??= /* @__PURE__ */ new Set()).add(t4), void 0 !== this.renderRoot && this.isConnected && t4.hostConnected?.();
      }
      removeController(t4) {
        this._$EO?.delete(t4);
      }
      _$E_() {
        const t4 = /* @__PURE__ */ new Map(), s4 = this.constructor.elementProperties;
        for (const i6 of s4.keys()) this.hasOwnProperty(i6) && (t4.set(i6, this[i6]), delete this[i6]);
        t4.size > 0 && (this._$Ep = t4);
      }
      createRenderRoot() {
        const t4 = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
        return S(t4, this.constructor.elementStyles), t4;
      }
      connectedCallback() {
        this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(true), this._$EO?.forEach(((t4) => t4.hostConnected?.()));
      }
      enableUpdating(t4) {
      }
      disconnectedCallback() {
        this._$EO?.forEach(((t4) => t4.hostDisconnected?.()));
      }
      attributeChangedCallback(t4, s4, i6) {
        this._$AK(t4, i6);
      }
      _$ET(t4, s4) {
        const i6 = this.constructor.elementProperties.get(t4), e6 = this.constructor._$Eu(t4, i6);
        if (void 0 !== e6 && true === i6.reflect) {
          const h3 = (void 0 !== i6.converter?.toAttribute ? i6.converter : u).toAttribute(s4, i6.type);
          this._$Em = t4, null == h3 ? this.removeAttribute(e6) : this.setAttribute(e6, h3), this._$Em = null;
        }
      }
      _$AK(t4, s4) {
        const i6 = this.constructor, e6 = i6._$Eh.get(t4);
        if (void 0 !== e6 && this._$Em !== e6) {
          const t5 = i6.getPropertyOptions(e6), h3 = "function" == typeof t5.converter ? { fromAttribute: t5.converter } : void 0 !== t5.converter?.fromAttribute ? t5.converter : u;
          this._$Em = e6;
          const r4 = h3.fromAttribute(s4, t5.type);
          this[e6] = r4 ?? this._$Ej?.get(e6) ?? r4, this._$Em = null;
        }
      }
      requestUpdate(t4, s4, i6) {
        if (void 0 !== t4) {
          const e6 = this.constructor, h3 = this[t4];
          if (i6 ??= e6.getPropertyOptions(t4), !((i6.hasChanged ?? f)(h3, s4) || i6.useDefault && i6.reflect && h3 === this._$Ej?.get(t4) && !this.hasAttribute(e6._$Eu(t4, i6)))) return;
          this.C(t4, s4, i6);
        }
        false === this.isUpdatePending && (this._$ES = this._$EP());
      }
      C(t4, s4, { useDefault: i6, reflect: e6, wrapped: h3 }, r4) {
        i6 && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t4) && (this._$Ej.set(t4, r4 ?? s4 ?? this[t4]), true !== h3 || void 0 !== r4) || (this._$AL.has(t4) || (this.hasUpdated || i6 || (s4 = void 0), this._$AL.set(t4, s4)), true === e6 && this._$Em !== t4 && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t4));
      }
      async _$EP() {
        this.isUpdatePending = true;
        try {
          await this._$ES;
        } catch (t5) {
          Promise.reject(t5);
        }
        const t4 = this.scheduleUpdate();
        return null != t4 && await t4, !this.isUpdatePending;
      }
      scheduleUpdate() {
        return this.performUpdate();
      }
      performUpdate() {
        if (!this.isUpdatePending) return;
        if (!this.hasUpdated) {
          if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
            for (const [t6, s5] of this._$Ep) this[t6] = s5;
            this._$Ep = void 0;
          }
          const t5 = this.constructor.elementProperties;
          if (t5.size > 0) for (const [s5, i6] of t5) {
            const { wrapped: t6 } = i6, e6 = this[s5];
            true !== t6 || this._$AL.has(s5) || void 0 === e6 || this.C(s5, void 0, i6, e6);
          }
        }
        let t4 = false;
        const s4 = this._$AL;
        try {
          t4 = this.shouldUpdate(s4), t4 ? (this.willUpdate(s4), this._$EO?.forEach(((t5) => t5.hostUpdate?.())), this.update(s4)) : this._$EM();
        } catch (s5) {
          throw t4 = false, this._$EM(), s5;
        }
        t4 && this._$AE(s4);
      }
      willUpdate(t4) {
      }
      _$AE(t4) {
        this._$EO?.forEach(((t5) => t5.hostUpdated?.())), this.hasUpdated || (this.hasUpdated = true, this.firstUpdated(t4)), this.updated(t4);
      }
      _$EM() {
        this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = false;
      }
      get updateComplete() {
        return this.getUpdateComplete();
      }
      getUpdateComplete() {
        return this._$ES;
      }
      shouldUpdate(t4) {
        return true;
      }
      update(t4) {
        this._$Eq &&= this._$Eq.forEach(((t5) => this._$ET(t5, this[t5]))), this._$EM();
      }
      updated(t4) {
      }
      firstUpdated(t4) {
      }
    };
    y.elementStyles = [], y.shadowRootOptions = { mode: "open" }, y[d("elementProperties")] = /* @__PURE__ */ new Map(), y[d("finalized")] = /* @__PURE__ */ new Map(), p?.({ ReactiveElement: y }), (a.reactiveElementVersions ??= []).push("2.1.1");
    var t2 = globalThis;
    var i3 = t2.trustedTypes;
    var s2 = i3 ? i3.createPolicy("lit-html", { createHTML: (t4) => t4 }) : void 0;
    var e3 = "$lit$";
    var h2 = `lit$${Math.random().toFixed(9).slice(2)}$`;
    var o3 = "?" + h2;
    var n3 = `<${o3}>`;
    var r3 = document;
    var l2 = () => r3.createComment("");
    var c3 = (t4) => null === t4 || "object" != typeof t4 && "function" != typeof t4;
    var a2 = Array.isArray;
    var u2 = (t4) => a2(t4) || "function" == typeof t4?.[Symbol.iterator];
    var d2 = "[ 	\n\f\r]";
    var f2 = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g;
    var v = /-->/g;
    var _ = />/g;
    var m = RegExp(`>|${d2}(?:([^\\s"'>=/]+)(${d2}*=${d2}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g");
    var p2 = /'/g;
    var g = /"/g;
    var $ = /^(?:script|style|textarea|title)$/i;
    var y2 = (t4) => (i6, ...s4) => ({ _$litType$: t4, strings: i6, values: s4 });
    var x = y2(1);
    var b2 = y2(2);
    var w = y2(3);
    var T = Symbol.for("lit-noChange");
    var E = Symbol.for("lit-nothing");
    var A = /* @__PURE__ */ new WeakMap();
    var C = r3.createTreeWalker(r3, 129);
    function P(t4, i6) {
      if (!a2(t4) || !t4.hasOwnProperty("raw")) throw Error("invalid template strings array");
      return void 0 !== s2 ? s2.createHTML(i6) : i6;
    }
    var V = (t4, i6) => {
      const s4 = t4.length - 1, o6 = [];
      let r4, l3 = 2 === i6 ? "<svg>" : 3 === i6 ? "<math>" : "", c4 = f2;
      for (let i7 = 0; i7 < s4; i7++) {
        const s5 = t4[i7];
        let a3, u3, d3 = -1, y3 = 0;
        for (; y3 < s5.length && (c4.lastIndex = y3, u3 = c4.exec(s5), null !== u3); ) y3 = c4.lastIndex, c4 === f2 ? "!--" === u3[1] ? c4 = v : void 0 !== u3[1] ? c4 = _ : void 0 !== u3[2] ? ($.test(u3[2]) && (r4 = RegExp("</" + u3[2], "g")), c4 = m) : void 0 !== u3[3] && (c4 = m) : c4 === m ? ">" === u3[0] ? (c4 = r4 ?? f2, d3 = -1) : void 0 === u3[1] ? d3 = -2 : (d3 = c4.lastIndex - u3[2].length, a3 = u3[1], c4 = void 0 === u3[3] ? m : '"' === u3[3] ? g : p2) : c4 === g || c4 === p2 ? c4 = m : c4 === v || c4 === _ ? c4 = f2 : (c4 = m, r4 = void 0);
        const x2 = c4 === m && t4[i7 + 1].startsWith("/>") ? " " : "";
        l3 += c4 === f2 ? s5 + n3 : d3 >= 0 ? (o6.push(a3), s5.slice(0, d3) + e3 + s5.slice(d3) + h2 + x2) : s5 + h2 + (-2 === d3 ? i7 : x2);
      }
      return [P(t4, l3 + (t4[s4] || "<?>") + (2 === i6 ? "</svg>" : 3 === i6 ? "</math>" : "")), o6];
    };
    var N = class _N {
      constructor({ strings: t4, _$litType$: s4 }, n4) {
        let r4;
        this.parts = [];
        let c4 = 0, a3 = 0;
        const u3 = t4.length - 1, d3 = this.parts, [f3, v2] = V(t4, s4);
        if (this.el = _N.createElement(f3, n4), C.currentNode = this.el.content, 2 === s4 || 3 === s4) {
          const t5 = this.el.content.firstChild;
          t5.replaceWith(...t5.childNodes);
        }
        for (; null !== (r4 = C.nextNode()) && d3.length < u3; ) {
          if (1 === r4.nodeType) {
            if (r4.hasAttributes()) for (const t5 of r4.getAttributeNames()) if (t5.endsWith(e3)) {
              const i6 = v2[a3++], s5 = r4.getAttribute(t5).split(h2), e6 = /([.?@])?(.*)/.exec(i6);
              d3.push({ type: 1, index: c4, name: e6[2], strings: s5, ctor: "." === e6[1] ? H : "?" === e6[1] ? I : "@" === e6[1] ? L : k }), r4.removeAttribute(t5);
            } else t5.startsWith(h2) && (d3.push({ type: 6, index: c4 }), r4.removeAttribute(t5));
            if ($.test(r4.tagName)) {
              const t5 = r4.textContent.split(h2), s5 = t5.length - 1;
              if (s5 > 0) {
                r4.textContent = i3 ? i3.emptyScript : "";
                for (let i6 = 0; i6 < s5; i6++) r4.append(t5[i6], l2()), C.nextNode(), d3.push({ type: 2, index: ++c4 });
                r4.append(t5[s5], l2());
              }
            }
          } else if (8 === r4.nodeType) if (r4.data === o3) d3.push({ type: 2, index: c4 });
          else {
            let t5 = -1;
            for (; -1 !== (t5 = r4.data.indexOf(h2, t5 + 1)); ) d3.push({ type: 7, index: c4 }), t5 += h2.length - 1;
          }
          c4++;
        }
      }
      static createElement(t4, i6) {
        const s4 = r3.createElement("template");
        return s4.innerHTML = t4, s4;
      }
    };
    function S2(t4, i6, s4 = t4, e6) {
      if (i6 === T) return i6;
      let h3 = void 0 !== e6 ? s4._$Co?.[e6] : s4._$Cl;
      const o6 = c3(i6) ? void 0 : i6._$litDirective$;
      return h3?.constructor !== o6 && (h3?._$AO?.(false), void 0 === o6 ? h3 = void 0 : (h3 = new o6(t4), h3._$AT(t4, s4, e6)), void 0 !== e6 ? (s4._$Co ??= [])[e6] = h3 : s4._$Cl = h3), void 0 !== h3 && (i6 = S2(t4, h3._$AS(t4, i6.values), h3, e6)), i6;
    }
    var M = class {
      constructor(t4, i6) {
        this._$AV = [], this._$AN = void 0, this._$AD = t4, this._$AM = i6;
      }
      get parentNode() {
        return this._$AM.parentNode;
      }
      get _$AU() {
        return this._$AM._$AU;
      }
      u(t4) {
        const { el: { content: i6 }, parts: s4 } = this._$AD, e6 = (t4?.creationScope ?? r3).importNode(i6, true);
        C.currentNode = e6;
        let h3 = C.nextNode(), o6 = 0, n4 = 0, l3 = s4[0];
        for (; void 0 !== l3; ) {
          if (o6 === l3.index) {
            let i7;
            2 === l3.type ? i7 = new R(h3, h3.nextSibling, this, t4) : 1 === l3.type ? i7 = new l3.ctor(h3, l3.name, l3.strings, this, t4) : 6 === l3.type && (i7 = new z(h3, this, t4)), this._$AV.push(i7), l3 = s4[++n4];
          }
          o6 !== l3?.index && (h3 = C.nextNode(), o6++);
        }
        return C.currentNode = r3, e6;
      }
      p(t4) {
        let i6 = 0;
        for (const s4 of this._$AV) void 0 !== s4 && (void 0 !== s4.strings ? (s4._$AI(t4, s4, i6), i6 += s4.strings.length - 2) : s4._$AI(t4[i6])), i6++;
      }
    };
    var R = class _R {
      get _$AU() {
        return this._$AM?._$AU ?? this._$Cv;
      }
      constructor(t4, i6, s4, e6) {
        this.type = 2, this._$AH = E, this._$AN = void 0, this._$AA = t4, this._$AB = i6, this._$AM = s4, this.options = e6, this._$Cv = e6?.isConnected ?? true;
      }
      get parentNode() {
        let t4 = this._$AA.parentNode;
        const i6 = this._$AM;
        return void 0 !== i6 && 11 === t4?.nodeType && (t4 = i6.parentNode), t4;
      }
      get startNode() {
        return this._$AA;
      }
      get endNode() {
        return this._$AB;
      }
      _$AI(t4, i6 = this) {
        t4 = S2(this, t4, i6), c3(t4) ? t4 === E || null == t4 || "" === t4 ? (this._$AH !== E && this._$AR(), this._$AH = E) : t4 !== this._$AH && t4 !== T && this._(t4) : void 0 !== t4._$litType$ ? this.$(t4) : void 0 !== t4.nodeType ? this.T(t4) : u2(t4) ? this.k(t4) : this._(t4);
      }
      O(t4) {
        return this._$AA.parentNode.insertBefore(t4, this._$AB);
      }
      T(t4) {
        this._$AH !== t4 && (this._$AR(), this._$AH = this.O(t4));
      }
      _(t4) {
        this._$AH !== E && c3(this._$AH) ? this._$AA.nextSibling.data = t4 : this.T(r3.createTextNode(t4)), this._$AH = t4;
      }
      $(t4) {
        const { values: i6, _$litType$: s4 } = t4, e6 = "number" == typeof s4 ? this._$AC(t4) : (void 0 === s4.el && (s4.el = N.createElement(P(s4.h, s4.h[0]), this.options)), s4);
        if (this._$AH?._$AD === e6) this._$AH.p(i6);
        else {
          const t5 = new M(e6, this), s5 = t5.u(this.options);
          t5.p(i6), this.T(s5), this._$AH = t5;
        }
      }
      _$AC(t4) {
        let i6 = A.get(t4.strings);
        return void 0 === i6 && A.set(t4.strings, i6 = new N(t4)), i6;
      }
      k(t4) {
        a2(this._$AH) || (this._$AH = [], this._$AR());
        const i6 = this._$AH;
        let s4, e6 = 0;
        for (const h3 of t4) e6 === i6.length ? i6.push(s4 = new _R(this.O(l2()), this.O(l2()), this, this.options)) : s4 = i6[e6], s4._$AI(h3), e6++;
        e6 < i6.length && (this._$AR(s4 && s4._$AB.nextSibling, e6), i6.length = e6);
      }
      _$AR(t4 = this._$AA.nextSibling, i6) {
        for (this._$AP?.(false, true, i6); t4 !== this._$AB; ) {
          const i7 = t4.nextSibling;
          t4.remove(), t4 = i7;
        }
      }
      setConnected(t4) {
        void 0 === this._$AM && (this._$Cv = t4, this._$AP?.(t4));
      }
    };
    var k = class {
      get tagName() {
        return this.element.tagName;
      }
      get _$AU() {
        return this._$AM._$AU;
      }
      constructor(t4, i6, s4, e6, h3) {
        this.type = 1, this._$AH = E, this._$AN = void 0, this.element = t4, this.name = i6, this._$AM = e6, this.options = h3, s4.length > 2 || "" !== s4[0] || "" !== s4[1] ? (this._$AH = Array(s4.length - 1).fill(new String()), this.strings = s4) : this._$AH = E;
      }
      _$AI(t4, i6 = this, s4, e6) {
        const h3 = this.strings;
        let o6 = false;
        if (void 0 === h3) t4 = S2(this, t4, i6, 0), o6 = !c3(t4) || t4 !== this._$AH && t4 !== T, o6 && (this._$AH = t4);
        else {
          const e7 = t4;
          let n4, r4;
          for (t4 = h3[0], n4 = 0; n4 < h3.length - 1; n4++) r4 = S2(this, e7[s4 + n4], i6, n4), r4 === T && (r4 = this._$AH[n4]), o6 ||= !c3(r4) || r4 !== this._$AH[n4], r4 === E ? t4 = E : t4 !== E && (t4 += (r4 ?? "") + h3[n4 + 1]), this._$AH[n4] = r4;
        }
        o6 && !e6 && this.j(t4);
      }
      j(t4) {
        t4 === E ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t4 ?? "");
      }
    };
    var H = class extends k {
      constructor() {
        super(...arguments), this.type = 3;
      }
      j(t4) {
        this.element[this.name] = t4 === E ? void 0 : t4;
      }
    };
    var I = class extends k {
      constructor() {
        super(...arguments), this.type = 4;
      }
      j(t4) {
        this.element.toggleAttribute(this.name, !!t4 && t4 !== E);
      }
    };
    var L = class extends k {
      constructor(t4, i6, s4, e6, h3) {
        super(t4, i6, s4, e6, h3), this.type = 5;
      }
      _$AI(t4, i6 = this) {
        if ((t4 = S2(this, t4, i6, 0) ?? E) === T) return;
        const s4 = this._$AH, e6 = t4 === E && s4 !== E || t4.capture !== s4.capture || t4.once !== s4.once || t4.passive !== s4.passive, h3 = t4 !== E && (s4 === E || e6);
        e6 && this.element.removeEventListener(this.name, this, s4), h3 && this.element.addEventListener(this.name, this, t4), this._$AH = t4;
      }
      handleEvent(t4) {
        "function" == typeof this._$AH ? this._$AH.call(this.options?.host ?? this.element, t4) : this._$AH.handleEvent(t4);
      }
    };
    var z = class {
      constructor(t4, i6, s4) {
        this.element = t4, this.type = 6, this._$AN = void 0, this._$AM = i6, this.options = s4;
      }
      get _$AU() {
        return this._$AM._$AU;
      }
      _$AI(t4) {
        S2(this, t4);
      }
    };
    var j = t2.litHtmlPolyfillSupport;
    j?.(N, R), (t2.litHtmlVersions ??= []).push("3.3.1");
    var B = (t4, i6, s4) => {
      const e6 = s4?.renderBefore ?? i6;
      let h3 = e6._$litPart$;
      if (void 0 === h3) {
        const t5 = s4?.renderBefore ?? null;
        e6._$litPart$ = h3 = new R(i6.insertBefore(l2(), t5), t5, void 0, s4 ?? {});
      }
      return h3._$AI(t4), h3;
    };
    var s3 = globalThis;
    var i4 = class extends y {
      constructor() {
        super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
      }
      createRenderRoot() {
        const t4 = super.createRenderRoot();
        return this.renderOptions.renderBefore ??= t4.firstChild, t4;
      }
      update(t4) {
        const r4 = this.render();
        this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t4), this._$Do = B(r4, this.renderRoot, this.renderOptions);
      }
      connectedCallback() {
        super.connectedCallback(), this._$Do?.setConnected(true);
      }
      disconnectedCallback() {
        super.disconnectedCallback(), this._$Do?.setConnected(false);
      }
      render() {
        return T;
      }
    };
    i4._$litElement$ = true, i4["finalized"] = true, s3.litElementHydrateSupport?.({ LitElement: i4 });
    var o4 = s3.litElementPolyfillSupport;
    o4?.({ LitElement: i4 });
    (s3.litElementVersions ??= []).push("4.2.1");
    var t3 = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 };
    var e4 = (t4) => (...e6) => ({ _$litDirective$: t4, values: e6 });
    var i5 = class {
      constructor(t4) {
      }
      get _$AU() {
        return this._$AM._$AU;
      }
      _$AT(t4, e6, i6) {
        this._$Ct = t4, this._$AM = e6, this._$Ci = i6;
      }
      _$AS(t4, e6) {
        return this.update(t4, e6);
      }
      update(t4, e6) {
        return this.render(...e6);
      }
    };
    var e5 = class extends i5 {
      constructor(i6) {
        if (super(i6), this.it = E, i6.type !== t3.CHILD) throw Error(this.constructor.directiveName + "() can only be used in child bindings");
      }
      render(r4) {
        if (r4 === E || null == r4) return this._t = void 0, this.it = r4;
        if (r4 === T) return r4;
        if ("string" != typeof r4) throw Error(this.constructor.directiveName + "() called with a non-string value");
        if (r4 === this.it) return this._t;
        this.it = r4;
        const s4 = [r4];
        return s4.raw = s4, this._t = { _$litType$: this.constructor.resultType, strings: s4, values: [] };
      }
    };
    e5.directiveName = "unsafeHTML", e5.resultType = 1;
    var o5 = e4(e5);
    window.render = B;
    window.html = x;
    window.Lit_Element = i4;
    window.Lit_UnsafeHtml = o5;
    window.Lit_Css = i;
  })();

  // ../../.nifty/files/alwaysload/fetchlassie.js
  var _timeoutWaitingAnimateId = null;
  var _activeRequestCount = 0;
  function FetchLassie(url, http_optsP, opts) {
    return new Promise(async (fetch_callback) => {
      const http_opts = http_optsP || { method: "GET", headers: {}, body: null };
      http_opts.method = typeof http_opts.method !== "undefined" ? http_opts.method : "GET";
      http_opts.headers = typeof http_opts.headers !== "undefined" ? http_opts.headers : {};
      http_opts.body = typeof http_opts.body !== "undefined" ? http_opts.body : null;
      if (!opts) {
        opts = { retries: 0, background: true, animate: true, cacheit: false };
      }
      opts.retries = opts.retries || 0;
      opts.background = opts.background || true;
      opts.animate = opts.animate || true;
      opts.cacheit = opts.cacheit || false;
      if (opts.cacheit) {
        const future_epoch_seconds = get_cache_future_epoch_seconds_from_str(opts.cacheit === true ? "5m" : opts.cacheit);
        http_opts.headers = http_opts.headers || {};
        http_opts.headers["Nifty-Cache"] = future_epoch_seconds.toString();
      }
      _activeRequestCount++;
      if (opts.background) {
        setBackgroundOverlay2(true);
      }
      if (opts.background && opts.animate && _timeoutWaitingAnimateId === null) {
        _timeoutWaitingAnimateId = setTimeout(() => {
          setWaitingAnimate2(true);
        }, 1e3);
      }
      if (!http_opts.headers["Content-Type"]) http_opts.headers["Content-Type"] = "application/json";
      if (!http_opts.headers["Accept"]) http_opts.headers["Accept"] = "application/json";
      http_opts.headers["sse_id"] = localStorage.getItem("sse_id") || null;
      if (opts.retries && opts.retries > 0) {
        http_opts.headers["exitdelay"] = 3.1;
      }
      let result = null;
      for (let i = 0; i < opts.retries + 1; i++) {
        result = await fetchit(url, http_opts);
        if (result.status !== 503) break;
        await new Promise((res) => setTimeout(res, 1500));
      }
      _activeRequestCount--;
      if (_activeRequestCount === 0) {
        if (_timeoutWaitingAnimateId !== null) {
          clearTimeout(_timeoutWaitingAnimateId);
          _timeoutWaitingAnimateId = null;
        }
        setBackgroundOverlay2(false);
        setWaitingAnimate2(false);
      }
      if (result.status !== 200) {
        fetch_callback({ headers: result.headers, status: result.status, statusText: result.statusText, ok: false });
        return;
      }
      try {
        const returnobj = { headers: result.headers, status: 200, statusText: result.statusText, ok: true };
        if (http_opts.headers["Accept"] === "application/json") {
          returnobj.data = await result.json();
        } else {
          returnobj.data = await result.text();
        }
        fetch_callback(returnobj);
      } catch (e) {
        fetch_callback({ status: 400, statusText: "Could not parse text or json", ok: false, headers: result.headers });
      }
    });
  }
  var fetchit = (url, http_opts) => new Promise((response_callback, _rej) => {
    fetch(url, http_opts).then(async (server_response) => {
      response_callback(server_response);
    });
  });
  function setBackgroundOverlay2(ison) {
    const xel = document.querySelector("#fetchlassy_overlay");
    if (ison) {
      xel.classList.add("active");
    } else {
      xel.classList.remove("active");
    }
  }
  function setWaitingAnimate2(ison) {
    const xel = document.querySelector("#fetchlassy_overlay .waiting_animate");
    if (ison) {
      xel.classList.add("active");
    } else {
      xel.classList.remove("active");
    }
  }
  function get_cache_future_epoch_seconds_from_str(cache_time_amount) {
    const normalized = cache_time_amount.trim().toLowerCase();
    const match = normalized.match(/^(\d{1,3})([smhd])$/);
    if (!match) {
      return Math.floor(Date.now() / 1e3).toString();
    }
    const amount = Number(match[1]);
    const unit = match[2];
    let multiplier = 1;
    if (unit === "m") multiplier = 60;
    if (unit === "h") multiplier = 3600;
    if (unit === "d") multiplier = 86400;
    const nowInSeconds = Math.floor(Date.now() / 1e3);
    return (nowInSeconds + amount * multiplier).toString();
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.FetchLassie = FetchLassie;

  // ../../.nifty/files/alwaysload/influxdb.js
  function Retrieve_Series(bucket, begins, ends, msrs, fields, tags, intrv, priors) {
    return new Promise(async (res, rej) => {
      const body = { bucket, begins, ends, msrs, fields, tags, intrv, priors };
      const r = await influx_fetch_paths("retrieve_series", body);
      if (!r.ok) {
        rej();
        return;
      }
      const parsed_data = r.data;
      for (let i = 0; i < parsed_data.length; i++) {
        for (let ii = 0; ii < parsed_data[i].length; ii++) {
          for (let iii = 0; iii < parsed_data[i][ii].points.length; iii++) {
            parsed_data[i][ii].points[iii].date = new Date(parsed_data[i][ii].points[iii].date);
          }
        }
      }
      res(parsed_data);
    });
  }
  function Retrieve_Points(bucket, begins, ends, msrs, fields, tags) {
    return new Promise(async (res, rej) => {
      const body = { bucket, begins, ends, msrs, fields, tags };
      const r = await influx_fetch_paths("retrieve_points", body);
      if (!r.ok) {
        rej();
        return;
      }
      const parsed_data = r.data;
      for (let i = 0; i < parsed_data.length; i++) {
        parsed_data[i].date = new Date(parsed_data[i].date);
        parsed_data[i].val = parsed_data[i].val === "true" ? true : false;
      }
      res(parsed_data);
    });
  }
  function Retrieve_Medians(bucket, begins, ends, dur_amounts, dur_units, msrs, fields, tags, aggregate_fn) {
    return new Promise(async (res, rej) => {
      const body = { bucket, begins, ends, dur_amounts, dur_units, msrs, fields, tags, aggregate_fn };
      const r = await influx_fetch_paths("retrieve_medians", body);
      if (!r.ok) {
        rej();
        return;
      }
      const parsed_data = r.data;
      res(parsed_data);
    });
  }
  function influx_fetch_paths(path, body) {
    return new Promise(async (res) => {
      const fetchopts = { method: "POST", body: JSON.stringify(body) };
      const r = await $N.FetchLassie("/api/influxdb_" + path, fetchopts);
      res(r);
    });
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.InfluxDB = { Retrieve_Series, Retrieve_Points, Retrieve_Medians };

  // ../../.nifty/files/alwaysload/sse.js
  var _sse_listeners = [];
  var _sse_event_source = null;
  function Init6() {
    let sse_id = localStorage.getItem("sse_id");
    if (!sse_id) {
      sse_id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      localStorage.setItem("sse_id", sse_id);
    }
    const is_localhost = self.location.hostname === "localhost";
    let event_source_url = "";
    if (is_localhost) event_source_url = "/sse_add_listener?id=" + sse_id;
    else if (location.hostname.includes("purewater")) event_source_url = "https://webapp-805737116651.us-central1.run.app/sse_add_listener?id=" + sse_id;
    else if (location.hostname.includes("purewater")) event_source_url = "https://webapp-805737116651.us-central1.run.app/sse_add_listener?id=" + sse_id;
    else event_source_url = "https://xenwebapp-962422772741.us-central1.run.app/sse_add_listener?id=" + sse_id;
    _sse_event_source = new EventSource(event_source_url);
    _sse_event_source.onerror = (_e) => {
    };
    _sse_event_source.addEventListener("connected", (_e) => {
    });
    _sse_event_source.addEventListener("datasync_doc_add", (e) => {
      handle_message({ action: "SSE_EVENT", eventname: "datasync_doc_add", data: e.data });
    });
    _sse_event_source.addEventListener("datasync_doc_patch", (e) => {
      handle_message({ action: "SSE_EVENT", eventname: "datasync_doc_patch", data: e.data });
    });
    _sse_event_source.addEventListener("datasync_doc_delete", (e) => {
      handle_message({ action: "SSE_EVENT", eventname: "datasync_doc_delete", data: e.data });
    });
    _sse_event_source.addEventListener("datasync_collection", (e) => {
      handle_message({ action: "SSE_EVENT", eventname: "datasync_collection", data: e.data });
    });
  }
  function Add_Listener(el, name, eventnames, priority_, callback_) {
    for (let i = 0; i < _sse_listeners.length; i++) {
      if (!_sse_listeners[i].el.parentElement) {
        _sse_listeners.splice(i, 1);
      }
    }
    const priority = priority_ || 0;
    const newlistener = { name, el, eventnames, priority, cb: callback_ };
    Remove_Listener(el, name);
    _sse_listeners.push(newlistener);
    _sse_listeners.sort((a, b) => a.priority - b.priority);
  }
  function Close() {
    if (_sse_event_source) {
      _sse_event_source.close();
    }
  }
  function Remove_Listener(el, name) {
    const i = _sse_listeners.findIndex((l) => l.el.tagName === el.tagName && l.name === name);
    if (i === -1) return;
    _sse_listeners.splice(i, 1);
  }
  function handle_message(data) {
    const eventname = data.eventname;
    const event_data = JSON.parse(data.data);
    handle_firestore_docs_from_worker(event_data, eventname);
  }
  function handle_firestore_docs_from_worker(data, eventname) {
    const paths = data.paths || (data.path ? [data.path] : []);
    if (data.path) delete data.path;
    data.paths = paths;
    const ls = _sse_listeners.filter((l) => {
      if (l.eventnames.includes(eventname)) return true;
    });
    if (!ls) throw new Error("should be at least one listener for FIRESTORE_COLLECTION, but none found");
    ls.forEach((l) => l.cb(data, eventname));
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.SSEvents = { Add_Listener, Remove_Listener };

  // ../../.nifty/files/alwaysload/logger.js
  var DeviceTypeE = (function(DeviceTypeE2) {
    DeviceTypeE2["desktop"] = "dsk";
    DeviceTypeE2["mobile"] = "mbl";
    DeviceTypeE2["tablet"] = "tbl";
    return DeviceTypeE2;
  })(DeviceTypeE || {});
  var BrowserE = (function(BrowserE2) {
    BrowserE2["chrome"] = "chr";
    BrowserE2["firefox"] = "frx";
    BrowserE2["safari"] = "saf";
    BrowserE2["other"] = "otr";
    return BrowserE2;
  })(BrowserE || {});
  var LOG_STORE_NAME = "pending_logs";
  var MAX_SENDBEACON_PAYLOAD_SIZE = 60 * 1024;
  function init() {
    $N.EngagementListen.Add_Listener(document.body, "logger", ["hidden"], null, () => {
      sendlogs();
    });
  }
  async function log(type, subject, message) {
    if (window.location.hostname === "localhost") return;
    let ts = Math.floor(Date.now() / 1e3);
    if (message.length > 36) {
      message = message.slice(0, 33) + "...";
    }
    const log_entry = { type, subject, message, ts };
    try {
      await $N.IDB.AddOne(LOG_STORE_NAME, log_entry);
    } catch {
    }
  }
  async function get() {
    let user_email = localStorage.getItem("user_email");
    if (!user_email) return;
    const url = "/api/logger/get?user_email=" + user_email;
    const csvstr = await $N.FetchLassie(url, { headers: { "Content-Type": "text/csv", "Accept": "text/csv" } }, {});
    if (!csvstr.ok) {
      alert("unable to retrieve logs");
      return;
    }
    $N.Utils.CSVDownload(csvstr.data, "logs");
  }
  async function sendlogs() {
    let all_logs;
    try {
      all_logs = await $N.IDB.GetAll([LOG_STORE_NAME]);
    } catch {
      return;
    }
    if (all_logs.get(LOG_STORE_NAME)?.length === 0) return;
    let logs_str = all_logs.get(LOG_STORE_NAME)?.map(format_logitem).join("\n") || "";
    let user_email = localStorage.getItem("user_email") || "unknown";
    logs_str = `${user_email}
${get_device()}
${get_browser()}
` + logs_str;
    if (logs_str.length > MAX_SENDBEACON_PAYLOAD_SIZE) {
      await $N.IDB.ClearAll(LOG_STORE_NAME).catch(() => null);
      return;
    }
    if (navigator.sendBeacon("/api/logger/save", logs_str)) {
      await $N.IDB.ClearAll(LOG_STORE_NAME).catch(() => null);
    }
  }
  function format_logitem(logitem) {
    return `${logitem.type},${logitem.subject},${logitem.message},${logitem.ts}`;
  }
  function get_device() {
    const ua = navigator.userAgent;
    const isTablet = /iPad|Tablet|PlayBook|Nexus 7|Nexus 10|KFAPWI/i.test(ua) || /(Android)/i.test(ua) && !/Mobile/i.test(ua);
    const isMobile = /Mobi|Mobile|iPhone|iPod|BlackBerry|Windows Phone|Opera Mini/i.test(ua);
    if (isTablet) {
      return "tbl";
    } else if (isMobile) {
      return "mbl";
    } else {
      return "dsk";
    }
  }
  function get_browser() {
    const ua = navigator.userAgent;
    let browser = "otr";
    if (/Firefox\/\d+/.test(ua)) {
      browser = "frx";
    } else if (/Edg\/\d+/.test(ua)) {
      browser = "chr";
    } else if (/Chrome\/\d+/.test(ua) && !/Edg\/\d+/.test(ua) && !/OPR\/\d+/.test(ua)) {
      browser = "chr";
    } else if (/Safari\/\d+/.test(ua) && !/Chrome\/\d+/.test(ua) && !/OPR\/\d+/.test(ua) && !/Edg\/\d+/.test(ua)) {
      browser = "saf";
    } else if (/OPR\/\d+/.test(ua)) {
      browser = "chr";
    }
    return browser;
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.Logger = { log, get };

  // ../../.nifty/files/alwaysload/engagementlisten.js
  var INTERVAL_RUN_BASE = 1 * 60 * 1e3;
  var INTERVAL_RUN_SECONDARY_CADENCE = 15 * 60 * 1e3;
  var INTERVAL_RUN_QUINARY_CADENCE = 24 * 60 * 60 * 1e3;
  var _elisteners = [];
  function Add_Listener2(el, name, type_, priority_, callback_) {
    const type = type_;
    for (let i = 0; i < _elisteners.length; i++) {
      if (!_elisteners[i].el.parentElement) {
        _elisteners.splice(i, 1);
      }
    }
    const existing_listener = _elisteners.find((l) => JSON.stringify(l.type) === JSON.stringify(type) && l.name === name);
    if (existing_listener) Remove_Listener2(el, name, type);
    const priority = priority_ || 0;
    _elisteners.push({ el, name, type, priority, callback: callback_ });
    _elisteners.sort((a, b) => a.priority - b.priority);
  }
  function Remove_Listener2(el, name, type_) {
    const i = _elisteners.findIndex((l) => l.el.tagName === el.tagName && l.name === name && JSON.stringify(l.type) === JSON.stringify(type_));
    if (i === -1) return;
    _elisteners.splice(i, 1);
  }
  function Init7() {
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        setTimeout(() => {
          for (const l of _elisteners.filter((l2) => l2.type.includes("visible"))) {
            l.callback("visible");
          }
        }, 500);
      } else if (document.visibilityState === "hidden") {
        setTimeout(() => {
          for (const l of _elisteners.filter((l2) => l2.type.includes("hidden"))) {
            l.callback("hidden");
          }
        }, 500);
      }
    });
    window.addEventListener("resize", () => {
      for (const l of _elisteners.filter((l2) => l2.type.includes("resize"))) {
        l.callback("resize");
      }
    });
    setInterval(() => {
      const now = Date.now();
      interval_run_if_time_secondary(now);
      interval_run_if_time_quinary(now);
    }, INTERVAL_RUN_BASE);
  }
  function interval_run_if_time_secondary(now) {
    const lastrun = localStorage.getItem("engagementlisten_lastsecondaryrun");
    if (!lastrun || now - parseInt(lastrun) > INTERVAL_RUN_SECONDARY_CADENCE) {
      for (const l of _elisteners.filter((l2) => l2.type.includes("15interval"))) {
        l.callback("15interval");
      }
      localStorage.setItem("engagementlisten_lastsecondaryrun", now.toString());
    }
  }
  function interval_run_if_time_quinary(now) {
    const lastrun = localStorage.getItem("engagementlisten_lastquinaryrun");
    if (!lastrun || now - parseInt(lastrun) > INTERVAL_RUN_QUINARY_CADENCE) {
      localStorage.setItem("lastdailyrun", now.toString());
    }
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.EngagementListen = { Init: Init7, Add_Listener: Add_Listener2, Remove_Listener: Remove_Listener2 };

  // ../../.nifty/files/alwaysload/indexeddb.js
  var _db = null;
  var _localdb_objectstores = [];
  var _db_name = "";
  var _db_version = 0;
  var Init8 = async (localdb_objectstores, db_name, db_version) => {
    _localdb_objectstores = localdb_objectstores;
    _db_name = db_name;
    _db_version = db_version;
  };
  var GetDB = () => new Promise(async (res, _rej) => {
    _db = await openindexeddb();
    res(_db);
  });
  var GetOne = (objectstore_name, id) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const transaction = _db.transaction(objectstore_name, "readonly");
    const objectStore = transaction.objectStore(objectstore_name);
    const result = await GetOne_S(objectStore, id);
    res(result);
  });
  var GetAll = (objectstore_names) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const returns = /* @__PURE__ */ new Map();
    const transaction = _db.transaction(objectstore_names, "readonly");
    const promises = [];
    for (const objectstore_name of objectstore_names) {
      const objectstore = transaction.objectStore(objectstore_name);
      promises.push(GetAll_S(objectstore));
    }
    const r = await Promise.all(promises);
    if (r === null) {
      res(/* @__PURE__ */ new Map());
      return;
    }
    for (let i = 0; i < r.length; i++) {
      returns.set(objectstore_names[i], r[i]);
    }
    res(returns);
  });
  var GetRangeAll = (objectstore_names, keys, lower_bounds, upper_bounds) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const returns = /* @__PURE__ */ new Map();
    const transaction = _db.transaction(objectstore_names, "readonly");
    const promises = [];
    let i = 0;
    for (const objectstore_name of objectstore_names) {
      const objectstore = transaction.objectStore(objectstore_name);
      promises.push(GetRangeAll_S(objectstore, keys[i], lower_bounds[i], upper_bounds[i]));
      i++;
    }
    const r = await Promise.all(promises);
    if (r === null) {
      res(/* @__PURE__ */ new Map());
      return;
    }
    for (let i2 = 0; i2 < r.length; i2++) {
      returns.set(objectstore_names[i2], r[i2]);
    }
    res(returns);
  });
  var ClearAll = (objectstore_name) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const tx = _db.transaction(objectstore_name, "readwrite");
    const objstore = tx.objectStore(objectstore_name);
    const request = objstore.clear();
    request.onerror = async () => {
      redirect_from_error3("ClearAll: clear failed");
    };
    tx.onerror = async () => {
      redirect_from_error3("ClearAll: tx error");
    };
    tx.oncomplete = () => {
      res(1);
    };
  });
  var AddOne = (objectstore_name, data) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const transaction = _db.transaction(objectstore_name, "readwrite");
    const objectstore = transaction.objectStore(objectstore_name);
    const keystring = await AddOne_S(objectstore, data);
    res(keystring);
  });
  var PutOne = (objectstore_name, data) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const transaction = _db.transaction(objectstore_name, "readwrite");
    const objectstore = transaction.objectStore(objectstore_name);
    const keystring = await PutOne_S(objectstore, data);
    res(keystring);
  });
  var DeleteOne = (objectstore_name, id) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const transaction = _db.transaction(objectstore_name, "readwrite");
    const objectstore = transaction.objectStore(objectstore_name);
    const r = await DeleteOne_S(objectstore, id);
    res(r);
  });
  var PutMany = (store_names, datas) => new Promise(async (resolve, _reject) => {
    if (_db === null) {
      await GetDB();
    }
    if (!datas.some((d) => d.length > 0)) {
      resolve();
      return;
    }
    const tx = _db.transaction(store_names, "readwrite", { durability: "relaxed" });
    let are_there_any_put_errors = false;
    for (let i = 0; i < datas.length; i++) {
      if (datas[i].length === 0) continue;
      const os = tx.objectStore(store_names[i]);
      for (let ii = 0; ii < datas[i].length; ii++) {
        const db_put = os.put(datas[i][ii]);
        db_put.onerror = (_event) => are_there_any_put_errors = true;
      }
    }
    tx.oncomplete = (_event) => {
      if (are_there_any_put_errors) redirect_from_error3("PutMany error");
      resolve();
    };
    tx.onerror = (_event) => {
      redirect_from_error3("PutMany error");
    };
  });
  var DeleteMany = (store_names, datas) => new Promise(async (resolve, _reject) => {
    if (_db === null) {
      await GetDB();
    }
    if (!datas.some((d) => d.length > 0)) {
      resolve();
      return;
    }
    const tx = _db.transaction(store_names, "readwrite", { durability: "relaxed" });
    let are_there_any_delete_errors = false;
    for (let i = 0; i < datas.length; i++) {
      if (datas[i].length === 0) continue;
      const os = tx.objectStore(store_names[i]);
      for (let ii = 0; ii < datas[i].length; ii++) {
        const db_delete = os.delete(datas[i][ii]);
        db_delete.onerror = (_event) => are_there_any_delete_errors = true;
      }
    }
    tx.oncomplete = (_event) => {
      if (are_there_any_delete_errors) redirect_from_error3("DeleteMany error");
      resolve();
    };
    tx.onerror = (_event) => {
      redirect_from_error3("DeleteMany error");
    };
  });
  var Count = (objectstore_name) => new Promise(async (res, _rej) => {
    if (_db === null) {
      await GetDB();
    }
    const transaction = _db.transaction(objectstore_name, "readonly");
    const objectstore = transaction.objectStore(objectstore_name);
    let count = 0;
    const request = objectstore.count();
    request.onsuccess = (ev) => count = Number(ev.target.result);
    request.onerror = async (_ev) => {
      await redirect_from_error3("Count: request error");
    };
    transaction.onerror = async () => {
      await redirect_from_error3("Count: tx error");
    };
    transaction.oncomplete = () => {
      res(count);
    };
  });
  var GetAll_S = (objectstore) => new Promise((res, _rej) => {
    const request = objectstore.getAll();
    request.onsuccess = (ev) => {
      const records = ev.target.result;
      res(records);
    };
    request.onerror = async (_ev) => {
      redirect_from_error3("GetAll_S: request error");
    };
  });
  var GetRangeAll_S = (objectstore, key, lower_bound, upper_bound) => new Promise((res, _rej) => {
    const key_range = IDBKeyRange.bound(lower_bound, upper_bound);
    const index = objectstore.index(key);
    const request = index.getAll(key_range);
    request.onsuccess = (ev) => {
      const records = ev.target.result;
      res(records);
    };
    request.onerror = async (_ev) => {
      redirect_from_error3("GetRangeAll_S: request error");
    };
  });
  var GetOne_S = (objectstore, id) => new Promise((res, _rej) => {
    const request = objectstore.get(id);
    request.onsuccess = (ev) => res(ev.target.result);
    request.onerror = async (_ev) => {
      redirect_from_error3("GetOne_S: request error");
    };
  });
  var AddOne_S = (objectstore, data) => new Promise((res, _rej) => {
    const request = objectstore.add(data);
    request.onsuccess = (ev) => res(ev.target.result);
    request.onerror = async (_ev) => {
      redirect_from_error3("AddOne_S: request error");
    };
  });
  var PutOne_S = (objectstore, data) => new Promise((res, _rej) => {
    const request = objectstore.put(data);
    request.onsuccess = (ev) => res(ev.target.result);
    request.onerror = async (_ev) => {
      redirect_from_error3("PutOne_S: request error");
    };
  });
  var DeleteOne_S = (objectstore, id) => new Promise((res, _rej) => {
    const request = objectstore.delete(id);
    request.onsuccess = (ev) => res(ev.target.result);
    request.onerror = async (ev) => {
      redirect_from_error3("DeleteOne_S: request error");
    };
  });
  var TXResult = (tx) => new Promise((res, _rej) => {
    tx.onerror = async () => {
      redirect_from_error3("TXResult: tx error");
    };
    tx.oncomplete = () => {
      res(1);
    };
    tx.onabort = async () => {
      redirect_from_error3("TXResult: tx aborted");
    };
  });
  var openindexeddb = () => new Promise(async (res, rej) => {
    let dbconnect = indexedDB.open(_db_name, _db_version);
    dbconnect.onerror = async (_event) => {
      await redirect_from_error3("openindexeddb: connection error");
      rej();
    };
    dbconnect.onsuccess = async (event) => {
      const db = event.target.result;
      res(db);
    };
    dbconnect.onupgradeneeded = (event) => {
      const db = event.target.result;
      _localdb_objectstores.forEach((dc) => {
        if (!db.objectStoreNames.contains(dc.name)) {
          const opts = { keyPath: "id" };
          if (dc.auto_increment === true) {
            opts.autoIncrement = true;
          }
          const objectStore = db.createObjectStore(dc.name, opts);
          (dc.indexes || []).forEach((prop) => {
            objectStore.createIndex(prop, prop, { unique: false });
          });
        }
      });
    };
  });
  async function redirect_from_error3(errmsg) {
    $N.Unrecoverable("Error", "Error in IndexedDB", "Reset App", "ixe", errmsg, null);
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.IDB = { GetDB, GetOne, GetAll, GetRangeAll, ClearAll, AddOne, PutOne, PutMany, DeleteMany, DeleteOne, Count, GetOne_S, GetAll_S, GetRangeAll_S, AddOne_S, PutOne_S, DeleteOne_S, TXResult };

  // ../../.nifty/files/alwaysload/utils.js
  function CSVDownload(csvstr, filename) {
    const blob = new Blob([csvstr], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.setAttribute("href", url);
    a.setAttribute("download", `${filename}.csv`);
    a.click();
    URL.revokeObjectURL(url);
  }
  function resolve_object_references(list, object_stores) {
    const lookup_maps = /* @__PURE__ */ new Map();
    const o = {};
    object_stores.forEach((storeData, storeName) => {
      o[storeName.slice(2)] = storeData;
    });
    for (const item of list) {
      for (const key in item) {
        const value = item[key];
        if (!value || typeof value !== "object" || !value.__path) {
          continue;
        }
        const [storeName, itemId] = value.__path;
        let lookup_map = lookup_maps.get(storeName);
        if (!lookup_map) {
          const storeData = o[storeName];
          lookup_map = /* @__PURE__ */ new Map();
          for (const storeItem of storeData) lookup_map.set(storeItem.id, storeItem);
          lookup_maps.set(storeName, lookup_map);
        }
        item[key + "ref"] = lookup_map.get(itemId);
      }
    }
    return list;
  }
  if (!window.$N) {
    window.$N = {};
  }
  window.$N.Utils = { CSVDownload, resolve_object_references };

  // ../../.nifty/files/main.js
  var INSTANCE_LAZYLOAD_DATA_FUNCS = { home: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    res({ d, refreshon: [] });
  }), adminsyncfrommastercsv: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    res({ d, refreshon: [] });
  }), machines: (pathparams, searchparams) => new Promise(async (res, rej) => {
    const d = /* @__PURE__ */ new Map();
    const hasSearch = searchparams.search_field && searchparams.search_val;
    const hasListView = searchparams.what && searchparams.secondary;
    const promises = [];
    if (hasSearch) {
      const field = encodeURIComponent(searchparams.search_field);
      const val = encodeURIComponent(searchparams.search_val);
      promises.push($N.FetchLassie(`/api/machines/search?field=${field}&val=${val}`, { method: "GET" }));
    } else if (hasListView) {
      promises.push($N.FetchLassie(`/api/machines?what=${searchparams.what}&secondary=${searchparams.secondary}`, { method: "GET" }));
    } else {
      promises.push($N.FetchLassie("/api/machines?what=notok&secondary=none", { method: "GET" }, { cacheit: "5s" }));
    }
    if (pathparams.quickdetails_machineid) {
      promises.push($N.FetchLassie("/api/machines/" + pathparams.quickdetails_machineid, { method: "GET" }));
    }
    const results = await Promise.all(promises);
    if (!results[0].ok) {
      rej();
      return;
    }
    d.set("machines_view_list", results[0].data);
    if (pathparams.quickdetails_machineid && results[1]) {
      if (!results[1].ok) {
        rej();
        return;
      }
      d.set("machines/" + pathparams.quickdetails_machineid, results[1].data);
    }
    res({ d, refreshon: ["machines"] });
  }), machine: (pathparams, searchparams) => new Promise(async (res, rej) => {
    const d = /* @__PURE__ */ new Map();
    const promises = [];
    promises.push($N.FetchLassie(`/api/machines/${pathparams.id}/view?firestore_refid=${searchparams.firestore_refid}`, { method: "GET" }));
    const results = await Promise.all(promises);
    if (!results[0].ok) {
      rej();
      return;
    }
    d.set(`machines/${pathparams.id}/view`, results[0].data);
    res({ d, refreshon: ["machines/" + pathparams.id] });
  }), machinetelemetry: (pathparams, _searchparams) => new Promise(async (res, rej) => {
    const d = /* @__PURE__ */ new Map();
    const r = await $N.FetchLassie(`/api/machines/${pathparams.id}`);
    if (!r.ok) {
      rej();
      return;
    }
    const rd = r.data;
    d.set(`machines/${pathparams.id}/telemetry_view`, [rd]);
    res({ d, refreshon: ["machines/" + pathparams.id] });
  }), notifications: (_pathparams, _searchparams) => new Promise(async (res, rej) => {
    const d = /* @__PURE__ */ new Map();
    const path = "/api/notifications/get_users_schedules";
    const promises = [$N.FetchLassie(path, { method: "GET" })];
    const results = await Promise.all(promises);
    if (!results[0].ok) {
      rej();
      return;
    }
    d.set("users_schedules", results[0].data);
    res({ d, refreshon: ["users"] });
  }) };
  var SETTINGS = { "MAIN": { "INFO": { "localdb_objectstores": [{ "name": "localdbsync_pending_sync_operations" }, { "name": "pending_logs", "auto_increment": true }, { "name": "__deleted_docs" }] }, "LAZYLOADS": [{ "type": "view", "urlmatch": "appmsgs", "name": "appmsgs", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "view", "urlmatch": "login", "name": "login", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "view", "urlmatch": "setup_push_allowance", "name": "setup_push_allowance", "is_instance": false, "dependencies": [{ "type": "component", "name": "ol" }, { "type": "component", "name": "btn" }], "auth": ["admin", "store_manager", "scanner"] }, { "type": "view", "urlmatch": "testassist", "name": "testassist", "is_instance": false, "dependencies": [{ "type": "component", "name": "btn" }], "auth": ["admin"] }, { "type": "component", "name": "graphing", "is_instance": false, "dependencies": [{ "type": "thirdparty", "name": "chartist" }], "auth": [] }, { "type": "component", "name": "ol2", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "ol", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "pol", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "tl", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "reveal", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "dselect", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "in", "is_instance": false, "dependencies": [{ "type": "component", "name": "dselect" }, { "type": "component", "name": "animeffect" }], "auth": [] }, { "type": "component", "name": "form2", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "in2", "is_instance": false, "dependencies": [{ "type": "component", "name": "dselect" }, { "type": "component", "name": "animeffect" }], "auth": [] }, { "type": "component", "name": "animeffect", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "toast", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "component", "name": "btn", "is_instance": false, "dependencies": [{ "type": "component", "name": "animeffect" }], "auth": [] }, { "type": "thirdparty", "name": "chartist", "is_instance": false, "dependencies": [], "auth": [] }, { "type": "lib", "name": "testlib", "is_instance": false, "dependencies": [], "auth": [] }] }, "INSTANCE": { "INFO": { "name": "INSTANCE_NAME", "shortname": "pwt", "firebase": { "project": "purewatertech", "identity_platform_key": "AIzaSyCdBd4FDBCZbL03_M4k2mLPaIdkUo32giI", "dbversion": 19 }, "localdb_objectstores": [{ "name": "nada_for_now" }] }, "LAZYLOADS": [{ "type": "view", "urlmatch": "home", "name": "home", "is_instance": true, "dependencies": [{ "type": "component", "name": "in2" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }], "auth": [] }, { "type": "view", "urlmatch": "adminsyncfrommastercsv", "name": "adminsyncfrommastercsv", "is_instance": true, "dependencies": [{ "type": "component", "name": "in2" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }], "auth": [] }, { "type": "view", "urlmatch": "machines", "subs": [{ "urlmatch": "quickdetails/:quickdetails_machineid" }, { "urlmatch": "map/:map_machineid" }, { "urlmatch": "add/:add_etcya" }], "name": "machines", "is_instance": true, "dependencies": [{ "type": "component", "name": "form2" }, { "type": "component", "name": "ol2" }, { "type": "component", "name": "pol" }, { "type": "component", "name": "in2" }, { "type": "component", "name": "dselect" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }, { "type": "component", "name": "metersreport" }, { "type": "component", "name": "machinedetails" }, { "type": "component", "name": "machinemap" }], "auth": ["user", "admin", "store_manager", "scanner"] }, { "type": "view", "urlmatch": "machines/:id", "subs": [{ "urlmatch": "quickdetails" }, { "urlmatch": "edit" }, { "urlmatch": "metersreport" }, { "urlmatch": "map" }], "name": "machine", "is_instance": true, "dependencies": [{ "type": "component", "name": "ol" }, { "type": "component", "name": "ol2" }, { "type": "component", "name": "reveal" }, { "type": "component", "name": "in" }, { "type": "component", "name": "in2" }, { "type": "component", "name": "dselect" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }, { "type": "component", "name": "metersreport" }, { "type": "component", "name": "machinedetails" }, { "type": "component", "name": "machinemap" }], "auth": ["user", "admin", "store_manager", "scanner"] }, { "type": "view", "urlmatch": "machines/:id/telemetry", "name": "machinetelemetry", "is_instance": true, "dependencies": [{ "type": "component", "name": "graphing" }, { "type": "component", "name": "ol" }, { "type": "component", "name": "toast" }], "auth": ["user", "admin", "store_manager", "scanner"] }, { "type": "view", "urlmatch": "notifications", "name": "notifications", "is_instance": true, "dependencies": [{ "type": "component", "name": "ol2" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "in" }, { "type": "component", "name": "reveal" }, { "type": "component", "name": "toast" }], "auth": ["user", "admin", "store_manager", "scanner"] }, { "type": "component", "name": "metersreport", "is_instance": true, "dependencies": [{ "type": "component", "name": "dselect" }, { "type": "component", "name": "btn" }, { "type": "component", "name": "in" }, { "type": "component", "name": "toast" }], "auth": [] }, { "type": "component", "name": "machinedetails", "is_instance": true, "dependencies": [{ "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }], "auth": [] }, { "type": "component", "name": "machinemap", "is_instance": true, "dependencies": [{ "type": "component", "name": "btn" }, { "type": "component", "name": "toast" }], "auth": [] }] } };
  var _serviceworker_reg;
  var LAZYLOAD_DATA_FUNCS = { appmsgs: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    res({ d, refreshon: [] });
  }), login: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    res({ d, refreshon: [] });
  }), setup_push_allowance: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    res({ d, refreshon: [] });
  }), testassist: (_pathparams, _searchparams) => new Promise(async (res, _rej) => {
    const d = /* @__PURE__ */ new Map();
    const dummydata = [{ dummytext: "Chair" }, { dummytext: "Table" }, { dummytext: "Lamp" }, { dummytext: "Sofa" }, { dummytext: "Desk" }, { dummytext: "Shelf" }, { dummytext: "Bed" }, { dummytext: "Rug" }];
    d.set("dummydata", dummydata);
    res({ d, refreshon: [] });
  }) };
  window.addEventListener("load", async (_e) => {
    const lazyload_data_funcs = { ...LAZYLOAD_DATA_FUNCS, ...INSTANCE_LAZYLOAD_DATA_FUNCS };
    const lazyloads = [...SETTINGS.MAIN.LAZYLOADS, ...SETTINGS.INSTANCE.LAZYLOADS];
    const all_localdb_objectstores = [...SETTINGS.INSTANCE.INFO.localdb_objectstores, ...SETTINGS.MAIN.INFO.localdb_objectstores];
    const lazyload_view_urlpatterns = Get_Lazyload_View_Url_Patterns(lazyloads);
    localStorage.setItem("identity_platform_key", SETTINGS.INSTANCE.INFO.firebase.identity_platform_key);
    if (window.APPVERSION > 0) {
      try {
        await setup_service_worker(lazyload_view_urlpatterns);
      } catch (err) {
        alert("unable to load service worker");
        console.error("Service Worker setup failed:", err);
        return;
      }
    }
    {
      Init8(all_localdb_objectstores, SETTINGS.INSTANCE.INFO.firebase.project, SETTINGS.INSTANCE.INFO.firebase.dbversion);
      Init7();
      Init(SETTINGS.INSTANCE.INFO.localdb_objectstores, SETTINGS.INSTANCE.INFO.firebase.project, SETTINGS.INSTANCE.INFO.firebase.dbversion);
      Init2(lazyload_data_funcs);
      Init3();
      init();
      Init4(lazyloads);
      await Init5();
    }
    let path;
    if (window.location.pathname === "/" || window.location.pathname === "" || window.location.pathname === "/index.html") {
      path = "home";
    } else {
      path = window.location.pathname.slice(3) + window.location.search;
    }
    setTimeout(() => Init6(), 1800);
  });
  window.addEventListener("online", () => {
    if (_serviceworker_reg?.active) {
      _serviceworker_reg.active.postMessage({ action: "networkchange", data: { state: "online" } });
    }
  });
  window.addEventListener("offline", () => {
    if (_serviceworker_reg?.active) {
      _serviceworker_reg.active.postMessage({ action: "networkchange", data: { state: "offline" } });
    }
  });
  var toast_id_counter = 0;
  function ToastShow(msg, level, _duration) {
    const toast_id = `maintoast-${toast_id_counter}`;
    const toast_el = document.createElement("c-toast");
    toast_el.id = toast_id;
    toast_el.setAttribute("msg", msg || "");
    toast_el.setAttribute("level", level?.toString() || "0");
    toast_el.setAttribute("duration", "2147483647");
    document.body.append(toast_el);
    toast_el.setAttribute("action", "run");
    toast_el.addEventListener("click", () => {
      if (toast_el.parentElement) {
        toast_el.remove();
      }
    });
    toast_el.addEventListener("done", () => {
      if (toast_el.parentElement) {
        toast_el.remove();
      }
    });
    setTimeout(() => {
      const toast_els = Array.from(document.querySelectorAll("c-toast"));
      let bottom_position = 20;
      for (const el of toast_els) {
        el.style.bottom = `${bottom_position}px`;
        bottom_position += 60;
      }
    }, 10);
  }
  $N.ToastShow = ToastShow;
  async function Unrecoverable(subj, msg, btnmsg, logsubj, logerrmsg, redirectionurl) {
    const redirect = redirectionurl || `/v/appmsgs?logsubj=${logsubj}`;
    setalertbox(subj, msg, btnmsg, redirect);
    $N.Logger.log(40, logsubj, logerrmsg || "");
  }
  $N.Unrecoverable = Unrecoverable;
  function setalertbox(subj, msg, btnmsg, redirect, clickHandler) {
    const modal = document.getElementById("alert_notice");
    if (!modal) return;
    const isAlreadyActive = modal.classList.contains("active");
    if (!isAlreadyActive) {
      modal.classList.add("active");
      const titleEl = document.getElementById("alert_notice_title");
      const btnReset = document.getElementById("alert_notice_btn");
      if (titleEl) titleEl.textContent = subj;
      if (btnReset) {
        btnReset.textContent = btnmsg;
        const newBtnReset = btnReset.cloneNode(true);
        btnReset.parentNode?.replaceChild(newBtnReset, btnReset);
        newBtnReset.addEventListener("click", () => {
          if (clickHandler) {
            clickHandler();
          } else {
            window.location.href = redirect;
          }
        });
      }
    }
    const msgContainer = document.getElementById("alert_notice_msg_container");
    if (msgContainer) {
      const newMsgEl = document.createElement("p");
      newMsgEl.textContent = msg;
      msgContainer.appendChild(newMsgEl);
      msgContainer.scrollTop = msgContainer.scrollHeight;
    }
  }
  var setup_service_worker = (lazyload_view_urlpatterns) => new Promise((resolve, reject) => {
    let hasPreviousController = navigator.serviceWorker.controller ? true : false;
    navigator.serviceWorker.register("/sw.js").then((registration) => {
      _serviceworker_reg = registration;
      navigator.serviceWorker.ready.then(() => {
        registration.active?.postMessage({ action: "initial_data_pass", id_token: localStorage.getItem("id_token"), token_expires_at: localStorage.getItem("token_expires_at"), refresh_token: localStorage.getItem("refresh_token"), user_email: localStorage.getItem("user_email"), lazyload_view_urlpatterns });
        resolve();
      }).catch((err) => {
        reject(err);
      });
      navigator.serviceWorker.addEventListener("message", (event) => {
        if (event.data.action === "update_auth_info") {
          localStorage.setItem("id_token", event.data.id_token);
          localStorage.setItem("token_expires_at", event.data.token_expires_at.toString());
          localStorage.setItem("refresh_token", event.data.refresh_token);
        } else if (event.data.action === "update_init") {
          Close();
          setTimeout(() => {
            if (_serviceworker_reg) _serviceworker_reg?.update();
          }, 300);
        } else if (event.data.action === "error_out") {
          if (event.data.subject === "sw4") {
            Unrecoverable("Not Authenticated", "Please Login", "Login", "sw4", event.data.errmsg, "/v/login");
          } else {
            Unrecoverable("App Error", event.data.errmsg, "Restart App", event.data.subject, event.data.errmsg, null);
          }
        } else if (event.data.action === "backonline") {
          document.dispatchEvent(new Event("backonline"));
        }
      });
      navigator.serviceWorker.addEventListener("controllerchange", onNewServiceWorkerControllerChange);
      navigator.serviceWorker.addEventListener("updatefound", (_e) => {
        Close();
      });
      function onNewServiceWorkerControllerChange() {
        if (!hasPreviousController) {
          hasPreviousController = true;
          return;
        }
        const origin = window.location.origin;
        window.location.href = "https://yavada.com/bouncebacktonifty.html?origin=" + encodeURIComponent(origin);
      }
    }).catch((err) => {
      reject(err);
    });
  });
})();
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
lit-html/directive.js:
lit-html/directives/unsafe-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
