const PRELOAD_BASE_ASSETS = [
    "/v/appmsgs",
    "/v/login",
    "/v/home",
    "/"
];
//const INITIAL_CHECK_CONNECTIVITY_INTERVAL = 5000;
const CONNECTEDSTATE_CHECK_TIMEOUT = 5000;
const PERIODIC_MAINTENANCE_INTERVAL = 60 * 60 * 1000; // every hour
const INITIAL_PERIODIC_MAINTENANCE_INTERVAL = 15 * 1000;
const DELAY_PRELOAD_BASE_ASSETS = 10 * 1000;
const MAX_CONNECTEDCHECK_RAPID_TRIES = 10;
const EXITDELAY = 9000 // just the default. can be overridden in the fetch request
;
let _cache_name = 'cacheV__3742__';
let _cache_version = Number(_cache_name.split("__")[1]);
let _id_token = "";
let _token_expires_at = 0;
let _refresh_token = "";
let _user_email = "";
let _lazyload_view_urlpatterns = [];
let _connectedstate = 0; // assume online at start
let _connectedcheck_timeout = 0;
let _connectedcheck_rapid_tries = 0;
self.addEventListener('install', (event)=>{
    //(self as any).skipWaiting();
    event.waitUntil((async ()=>{
        // Optionally, pre-cache any needed static assets here:
        // const cache = await caches.open(CACHE_NAME);
        // await cache.addAll([
        //   '/index.html',
        //   '/main.js',
        //   '/styles.css',
        //   ...
        // ]);
        await self.skipWaiting();
    })());
});
self.addEventListener('activate', (event)=>{
    event.waitUntil((async ()=>{
        const cacheKeys = await caches.keys();
        for (const key of cacheKeys){
            if (key !== _cache_name) {
                await caches.delete(key);
            }
        }
        await self.clients.claim();
        setTimeout(()=>preload_base_assets_into_cache(PRELOAD_BASE_ASSETS), DELAY_PRELOAD_BASE_ASSETS);
    })());
});
self.addEventListener('controllerchange', (_e)=>{});
self.addEventListener('fetch', (e)=>{
    let promise = new Promise(async (res, _rej)=>{
        let requesturltype = 2// default view_Url
        ;
        let response = null;
        const pathname = new URL(e.request.url).pathname;
        if (e.request.url.includes("identitytoolkit.googleapis.com") || e.request.url.includes("sse_add_listener")) {
            const r = await fetch(e.request);
            res(r);
            return;
        }
        // Determine request URL type based on path -- treat root as home view
        if (pathname.startsWith('/v/') || pathname === '/') {
            requesturltype = 2;
            response = await handle_file_call(e.request, pathname, requesturltype); // always returns a response
        } else if (pathname.startsWith('/api/')) {
            requesturltype = 0;
            response = await handle_data_call(e.request); // always returns a response
        } else if (pathname.startsWith('/assets/') || pathname.startsWith('/favicon.ico') || pathname.startsWith('/app.webmanifest') || pathname.startsWith('/shared_worker.js')) {
            requesturltype = 1;
            response = await handle_file_call(e.request, pathname, requesturltype); // always returns a response
        } else {
            // Pass through the request as-is for unrecognized URL patterns
            try {
                const response = await fetch(e.request);
                res(response);
            } catch (error) {
                res(new Response(null, {
                    status: 503,
                    statusText: 'Network error'
                }));
            }
            return;
        }
        if (response && response.status !== 200) {
            // if theres a call to error_out, this delay gives the main thread a chance to receive the message and call Unrecoverable if needed 
            // this allows main to have precedence on the Unrecoverable call, instead of instance that might make the same call because of failed fetch call
            setTimeout(()=>{
                res(response);
            }, 50);
        } else {
            res(response);
        }
    });
    e.respondWith(promise);
});
self.addEventListener('message', async (e)=>{
    if (e.data.action === "update") {
        //@ts-ignore
        self.registration?.update();
    } else if (e.data.action === "initial_data_pass") {
        _id_token = e.data.id_token;
        _token_expires_at = Number(e.data.token_expires_at);
        _refresh_token = e.data.refresh_token;
        _user_email = e.data.user_email;
        _lazyload_view_urlpatterns = e.data.lazyload_view_urlpatterns;
        clearTimeout(_connectedcheck_timeout); // probably not needed since this should be the first call 	
        setTimeout(()=>periodicmaintenance(), INITIAL_PERIODIC_MAINTENANCE_INTERVAL);
        connectedcheck();
    } else if (e.data.action === 'networkchange') {
        setTimeout(()=>{
            clearTimeout(_connectedcheck_timeout);
            connectedcheck();
        }, 750); // give it a timeout because the phone might be active on the cell network but not actually online just yet
    }
});
self.addEventListener('push', (e)=>{
    if (self.Notification.permission == 'denied') {
        return;
    }
    if (self.Notification.permission == 'default') {
    //
    }
    try {
        const msg = e.data.json().data;
        const options = {
            body: msg.body
        };
        e.waitUntil(self.registration.showNotification(msg.title, options));
    } catch (err) {
        throw new Error('Error in SW: ' + err);
    }
});
self.addEventListener('notificationclick', (event)=>{
    event.waitUntil();
});
/*
self.addEventListener("pushsubscriptionchange", (event) => {

    const subscription = (self as any).registration.pushManager.subscribe(event.oldSubscription.options)

    .then((subscription) =>
    fetch("register", {
    method: "post",
    headers: {
    "Content-type": "application/json",
    },
    body: JSON.stringify({
    endpoint: subscription.endpoint,
    }),
    }),
    );
    event.waitUntil(subscription);
    },

    false,
)
*/ /*
async function check_update_polling() {

	while (true) {

		await new Promise(r => setTimeout(r, 3000))

		console.log("check_update_polling")
		const response = await fetch('/api/latest_app_version')
		const server_version = Number(await response.text())

		//@ts-ignore
		//self.clients.matchAll().then((clients:any) => {
		//	clients.forEach((client:any) => {
		//		client.postMessage({ msg: "testlog", cache_version, server_version })
		//	})
		//})

		//@ts-ignore
		if (Number(server_version) != cache_version && self.registration && self.registration.update) {
			//@ts-ignore
			self.registration?.update()
		}
    }
}
*/ const handle_data_call = (r)=>new Promise(async (res, _rej)=>{
        // TODO: this basically disallows offline use. I want to fully allow offline use but that requires more code i don't have now
        if (_connectedstate === 1) {
            res(new Response(null, {
                status: 503,
                statusText: 'Network error - App Offline',
                headers: new Headers()
            }));
            return;
        }
        let ar;
        try {
            ar = await authrequest();
        } catch  {
            res(new Response(null, {
                status: 401,
                statusText: 'Unauthorized',
                headers: new Headers()
            }));
            return;
        }
        const is_appapi = r.url.includes("/api/") ? true : false;
        const base_headers = new Headers(r.headers);
        if (is_appapi) {
            base_headers.append('versionofapp', _cache_version.toString());
            base_headers.append('Authorization', `Bearer ${_id_token}`);
        }
        const should_cache = base_headers.has('Nifty-Cache');
        const cache_api = should_cache ? await caches.open(_cache_name) : null;
        if (should_cache) {
            const cached_response = await cache_api.match(r);
            if (cached_response) {
                const keys = await cache_api.keys();
                const req = keys.find((k)=>k.url === r.url && k.method === r.method && k.headers.has('Nifty-Cache'));
                const cache_ts = req?.headers.get('Nifty-Cache') || null;
                const ts = cache_ts ? Number(cache_ts) : null;
                if (ts && !isNaN(ts)) {
                    const nowts = Math.round(Date.now() / 1000);
                    if (nowts > ts) {
                    // cache expired. default to proceed to network fetch
                    } else {
                        const headers_with_flag = new Headers(cached_response.headers);
                        headers_with_flag.set('Nifty-Is-Cache', 'true');
                        const flagged_response = new Response(cached_response.body, {
                            status: cached_response.status,
                            statusText: cached_response.statusText,
                            headers: headers_with_flag
                        });
                        res(flagged_response);
                        return;
                    }
                }
            }
        }
        const { signal } = set_abort_signal(r.headers);
        const network_request = new Request(r, {
            headers: base_headers,
            cache: 'no-store',
            signal
        });
        let server_response;
        try {
            server_response = await fetch(network_request);
        } catch (_err) {
            res(new Response(null, {
                status: 503,
                statusText: 'Network error',
                headers: new Headers()
            }));
            return;
        }
        if (is_appapi && server_response.status === 401) {
            await error_out("sw4", "");
            res(new Response(null, {
                status: 401,
                statusText: 'Unauthorized',
                headers: new Headers()
            }));
            return;
        } else if (is_appapi && server_response.headers.get('updatedrequired')) {
            self.clients.matchAll().then((clients)=>{
                clients.forEach((client)=>{
                    client.postMessage({
                        action: 'update_init'
                    });
                });
            });
            // resolve, otherwise the fetch request will stay pending and disrupt service worker from updating
            res(new Response(null, {
                status: 426,
                statusText: 'updatedrequired',
                headers: new Headers()
            }));
            return;
        } else if (server_response.status === 200 && should_cache) {
            cache_api.put(network_request, server_response.clone());
        }
        res(server_response);
    });
/*
const revalidate_cached_request = async (original_request: Request, _cached_response: Response, response_digest: string, base_headers: Headers, cache_api: Cache) => new Promise<void>(async (res, _rej) => {

	let r:Response;

	base_headers.set('Nifty-Cache-Digest', response_digest);

	const { signal } = set_abort_signal(base_headers)
	const cache_refresh_request = new Request(original_request, { headers: base_headers, cache: 'no-store', signal });

	try { r = await fetch(cache_refresh_request); } 
	catch (_err) { console.error("revalidate_cached_request fetch error"); res(); return; }

	if (r.status === 304) {   console.log("no modifications"); return;   }

	if (r.status !== 200) {   res(); return;   }

	await cache_api.put(cache_refresh_request, r.clone());

	(self as any).clients.matchAll().then((clients:any) => {
		clients.forEach((client:any) => {
			client.postMessage({ action: 'cache_revalidated', url: original_request.url });
		})
	})
});
*/ const handle_file_call = (nr, pathname, requesturltype)=>new Promise(async (res, _rej)=>{
        const viewname = requesturltype === 2 ? get_view_name_from_url(pathname) : null;
        const request_for_viewurl = viewname ? new Request("/v/" + viewname) : null;
        const cache = await caches.open(_cache_name);
        const match_r = await cache.match(request_for_viewurl || nr);
        if (match_r) {
            res(match_r);
            return;
        }
        if (_connectedstate === 1) {
            res(set_failed_file_response(nr));
            return;
        }
        const { signal, abortsignal_timeoutid } = set_abort_signal(nr.headers);
        let r;
        try {
            r = await fetch(nr, {
                signal
            });
        } catch (err) {
            clearTimeout(abortsignal_timeoutid);
            res(set_failed_file_response(nr));
        }
        clearTimeout(abortsignal_timeoutid);
        if (r.status !== 200) {
            res(set_failed_file_response(nr));
        }
        if (r.status === 200 && should_url_be_cached(pathname)) {
            cache.put(request_for_viewurl || nr, r.clone());
        }
        res(r);
    });
const get_view_name_from_url = (pathname)=>{
    pathname = pathname.slice(3); // remove leading "/v/"
    for (const [viewname, pattern] of _lazyload_view_urlpatterns){
        const regex = new RegExp(pattern);
        if (regex.test(pathname)) return viewname;
    }
    return null;
};
const set_failed_file_response = (nr)=>{
    return nr.url.includes("/v/") ? set_failed_file_response_htmlpage(nr) : set_failed_file_response_other(nr);
};
const set_failed_file_response_htmlpage = (_nr)=>{
    let headers = new Headers({
        'Content-Type': 'text/html; charset=UTF-8',
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
        'X-Content-Type-Options': 'nosniff'
    });
    const responsebody = `<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Unable To Load Page</title>
	</head>
	<body>
		<script>
			setTimeout(()=> {
				window.location.href = "/v/appmsgs?logsubj=sw4&logmsg=Unable to load page - " + window.location.href
			}, 2000)
		</script>
	</body>
	</html>`;
    const returnresponse = new Response(responsebody, {
        status: 200,
        statusText: 'OK',
        headers: headers
    });
    return returnresponse;
};
const set_failed_file_response_other = (_nr)=>{
    let headers = {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0'
    };
    const responsebody = `Unable to Load File`;
    const returnresponse = new Response(responsebody, {
        status: 503,
        statusText: 'Network error',
        headers
    });
    return returnresponse;
};
function set_abort_signal(headers) {
    let controller = new AbortController();
    const { signal } = controller;
    const custom_exitdelay = headers.get("exitdelay");
    const exitdelay = custom_exitdelay ? parseFloat(custom_exitdelay) * 1000 : EXITDELAY;
    const abortsignal_timeoutid = setTimeout(()=>{
        controller.abort();
    }, exitdelay);
    return {
        signal,
        abortsignal_timeoutid
    };
}
function should_url_be_cached(pathname) {
    if (pathname.includes(".webmanifest") || pathname.includes("/assets/") || pathname.includes("/v/") || pathname === "/") {
        return true;
    } else if (pathname.endsWith(".js")) {
        return true;
    } else {
        return false;
    }
}
const authrequest = ()=>new Promise(async (res, rej)=>{
        if (!_id_token) {
            await error_out("sw4", "authrequest no token in browser storage");
            rej("No token in browser storage");
            return;
        }
        if (Date.now() / 1000 > _token_expires_at - 30) {
            const body = {
                refresh_token: _refresh_token
            };
            const { signal, abortsignal_timeoutid } = set_abort_signal(new Headers()); // dumb header, not used
            fetch('/api/refresh_auth', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body),
                signal: signal
            }).then(async (r)=>{
                clearTimeout(abortsignal_timeoutid);
                let data = await r.json();
                if (data.error) {
                    await error_out("sw4", "authrequest refresh failed - " + data.error.message);
                    rej("Refresh failed");
                } else {
                    _id_token = data.id_token;
                    _refresh_token = data.refresh_token;
                    _token_expires_at = Math.floor(Date.now() / 1000) + Number(data.expires_in);
                    self.clients.matchAll().then((clients)=>{
                        clients.forEach((client)=>{
                            client.postMessage({
                                action: 'update_auth_info',
                                id_token: _id_token,
                                refresh_token: _refresh_token,
                                token_expires_at: _token_expires_at
                            });
                        });
                    });
                    res("ok");
                }
            }).catch(async (_err)=>{
                clearTimeout(abortsignal_timeoutid);
                rej("Network error");
            });
        } else {
            res("ok");
        }
    });
const error_out = (subject, errmsg = "")=>new Promise((res, _rej)=>{
        self.clients.matchAll().then((clients)=>{
            clients.forEach((client)=>{
                client.postMessage({
                    action: 'error_out',
                    subject,
                    errmsg
                });
            });
        });
        // by the time this settimeout hits, the main thread has been notified and should have already completely redirected the app to error page
        setTimeout(()=>{
            res(1);
        }, 100);
    });
/*
function logit(type:number, subject:string, msg:string="") {

	(self as any).clients.matchAll().then((clients:any) => {
		setTimeout(()=> {
			clients.forEach((client: any) => {
				client.postMessage({
					action: 'logit',
					type,
					subject,
					msg
				})
			})
		},100)
	})
}
*/ const connectedcheck = async ()=>{
    const navigOn = self.navigator.onLine ? true : false;
    if (_connectedstate === 0 && navigOn) {
        _connectedcheck_timeout = setTimeout(()=>connectedcheck(), CONNECTEDSTATE_CHECK_TIMEOUT);
        return;
    }
    if (_connectedstate === 0 && !navigOn) {
        _connectedstate = 1;
        _connectedcheck_timeout = setTimeout(()=>connectedcheck(), CONNECTEDSTATE_CHECK_TIMEOUT);
        return;
    }
    // all appears to be still offline, so just keep waiting
    if (_connectedstate === 1 && !navigOn) {
        _connectedcheck_timeout = setTimeout(()=>connectedcheck(), CONNECTEDSTATE_CHECK_TIMEOUT);
        return;
    }
    // at this point, internal state is offline, but navigator says online, so do a fetch test
    const controller = new AbortController();
    setTimeout(()=>controller.abort(), 3000);
    await fetch('/api/ping', {
        signal: controller.signal
    }).then(()=>{
        _connectedstate = 0;
        _connectedcheck_timeout = setTimeout(()=>connectedcheck(), CONNECTEDSTATE_CHECK_TIMEOUT);
        _connectedcheck_rapid_tries = 0;
        // let the main thread know we're back online
        self.clients.matchAll().then((clients)=>{
            clients.forEach((client)=>{
                client.postMessage({
                    action: 'backonline'
                });
            });
        });
    }).catch(()=>{
        _connectedstate = 1;
        if (_connectedcheck_rapid_tries < MAX_CONNECTEDCHECK_RAPID_TRIES) {
            _connectedcheck_timeout = setTimeout(()=>connectedcheck(), 500);
            _connectedcheck_rapid_tries += 1;
        } else {
            _connectedcheck_timeout = setTimeout(()=>connectedcheck(), CONNECTEDSTATE_CHECK_TIMEOUT);
        }
    });
};
const periodicmaintenance = async ()=>{
    /*	right now, all this does is just yoink out caches older than what their Nifty-Cache header says
	*/ const now = Math.round(Date.now() / 1000);
    let cache = await caches.open(_cache_name);
    const keys = await cache.keys();
    keys.forEach((req)=>{
        const tsstring = req.headers.get('Nifty-Cache');
        if (!tsstring) return;
        const ts = Number(tsstring);
        if (now > ts) {
            cache.delete(req.url);
        }
    });
    setTimeout(()=>periodicmaintenance(), PERIODIC_MAINTENANCE_INTERVAL);
};
const preload_base_assets_into_cache = (assets)=>new Promise(async (res, _rej)=>{
        const cache = await caches.open(_cache_name);
        const promises = assets.map(async (url)=>{
            try {
                const cached_response = await cache.match(url);
                if (cached_response) {
                    return 1; // Already cached
                }
                const controller = new AbortController();
                const timeout = setTimeout(()=>controller.abort(), EXITDELAY); // Timeout for individual fetch
                const response = await fetch(url, {
                    signal: controller.signal
                });
                clearTimeout(timeout);
                if (response && response.status === 200) {
                    await cache.put(url, response.clone());
                    return 1; // Fetched and cached
                }
                return 0;
            } catch (error) {
                return 0;
            }
        });
        Promise.all(promises).then(()=>{
            res(1);
        });
    });

